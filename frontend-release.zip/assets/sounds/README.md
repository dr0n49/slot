# Casino sound placeholders

Drop replacement files here using the **same basename** (e.g. `card_deal.mp3`).
Supported extensions: `.mp3`, `.wav`, `.ogg`, `.m4a`.

| File | Used for |
|------|----------|
| `background_music.mp3` | Looping casino BGM |
| `card_deal.mp3` | Normal card deal slap (per card) |
| `card_deal_turbo.mp3` | Turbo/Speed deal slap |
| `risk_card_appear.mp3` | Double-up closed risk card appears |
| `risk_card_flip.mp3` | Double-up card flip |
| `risk_win.mp3` | Double-up survived |
| `risk_lose.mp3` | Double-up miss |
| `button_click.mp3` | UI buttons + HELD toggle |
| `win_small.mp3` | Small/medium hand wins |
| `win_big.mp3` | Royal Flush, Straight Flush, Quads, Full House |

Regenerate synth placeholders:

```bash
node scripts/generate-sound-placeholders.mjs
node scripts/generate-sound-placeholders.mjs --only=background_music
```
