export default {
	SETTINGS: 'SETTINGS',
};
