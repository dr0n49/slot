export * from './src/rgsFetcher';
