"""Optimiser setup, derived from math_params.py."""

import os
import sys

from optimization_program.optimization_config import (
    ConstructConditions,
    ConstructFenceBias,
    ConstructParameters,
    ConstructScaling,
    verify_optimization_input,
)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import math_params as P  # noqa: E402


class OptimizationSetup:
    """Amends game_config.opt_params, which is required to setup the maths configuration file."""

    def __init__(self, game_config):
        self.game_config = game_config
        cap = P.WINCAP
        base_share = P.BASE_MODE["rtp_share"]
        base_hr = P.BASE_MODE["hit_rate"]
        basegame_rtp = round(P.RTP - base_share["wincap"] - base_share["freegame"] - base_share["0"], 5)
        bonus_rtp = round(P.RTP - P.BONUS_MODE["rtp_share"]["wincap"], 5)
        opt = P.OPTIMISER

        self.game_config.opt_params = {
            "base": {
                "conditions": {
                    "wincap": ConstructConditions(
                        rtp=base_share["wincap"], av_win=cap, search_conditions=cap
                    ).return_dict(),
                    "0": ConstructConditions(rtp=0, av_win=0, search_conditions=0).return_dict(),
                    "freegame": ConstructConditions(
                        rtp=base_share["freegame"], hr=base_hr["freegame"], search_conditions={"symbol": "scatter"}
                    ).return_dict(),
                    "basegame": ConstructConditions(hr=base_hr["basegame"], rtp=basegame_rtp).return_dict(),
                },
                "scaling": ConstructScaling(
                    [
                        {"criteria": "basegame", "scale_factor": 1.4, "win_range": (1, 5), "probability": 1.0},
                        {"criteria": "basegame", "scale_factor": 1.3, "win_range": (15, 40), "probability": 1.0},
                        {"criteria": "freegame", "scale_factor": 1.2, "win_range": (150, 500), "probability": 1.0},
                        {"criteria": "freegame", "scale_factor": 1.3, "win_range": (500, 1200), "probability": 1.0},
                    ]
                ).return_dict(),
                "parameters": ConstructParameters(
                    num_show=opt["num_show"],
                    num_per_fence=opt["num_per_fence"],
                    min_m2m=4,
                    max_m2m=8,
                    pmb_rtp=1.0,
                    sim_trials=opt["sim_trials"],
                    test_spins=[50, 100, 200],
                    test_weights=[0.3, 0.4, 0.3],
                    score_type="rtp",
                ).return_dict(),
                "distribution_bias": ConstructFenceBias(
                    applied_criteria=["basegame"], bias_ranges=[(2.0, 6.0)], bias_weights=[0.5]
                ).return_dict(),
            },
            "bonus": {
                "conditions": {
                    "wincap": ConstructConditions(
                        rtp=P.BONUS_MODE["rtp_share"]["wincap"], av_win=cap, search_conditions=cap
                    ).return_dict(),
                    "freegame": ConstructConditions(rtp=bonus_rtp, hr="x").return_dict(),
                },
                "scaling": ConstructScaling(
                    [
                        {"criteria": "freegame", "scale_factor": 0.9, "win_range": (20, 60), "probability": 1.0},
                        {"criteria": "freegame", "scale_factor": 1.3, "win_range": (300, 1200), "probability": 1.0},
                    ]
                ).return_dict(),
                "parameters": ConstructParameters(
                    num_show=opt["num_show"],
                    num_per_fence=opt["num_per_fence"],
                    min_m2m=4,
                    max_m2m=8,
                    pmb_rtp=1.0,
                    sim_trials=opt["sim_trials"],
                    test_spins=[10, 20, 50],
                    test_weights=[0.6, 0.2, 0.2],
                    score_type="rtp",
                ).return_dict(),
            },
        }

        verify_optimization_input(self.game_config, self.game_config.opt_params)
