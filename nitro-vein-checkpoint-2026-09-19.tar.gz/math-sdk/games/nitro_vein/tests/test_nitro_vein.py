"""Math tests for NITRO VEIN.

Run from the math-sdk root:

    PYTHONPATH=. pytest games/nitro_vein/tests -q

The books-replay tests need the published books (`python games/nitro_vein/run.py`);
they are skipped when those have not been generated. They re-implement the ways
evaluator, the cascade rule and the Blast Ladder *independently* of the game code
and replay every sampled book, so a regression in either side is caught.
"""

import csv
import io
import json
import math
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
GAME_DIR = os.path.dirname(HERE)
sys.path.insert(0, GAME_DIR)
import math_params as P  # noqa: E402

PUBLISH = os.path.join(GAME_DIR, "library", "publish_files")
REELS = os.path.join(GAME_DIR, "reels")
PADDED = P.NUM_ROWS + 2


# --------------------------------------------------------------------------- #
# parameters
# --------------------------------------------------------------------------- #
def test_paytable_is_monotonic_and_covers_every_paying_symbol():
    assert set(P.PAYTABLE) == set(P.PAYING_SYMBOLS)
    for sym, pays in P.PAYTABLE.items():
        assert sorted(pays) == [4, 5], sym
        assert 0 < pays[4] < pays[5], sym
    order = ["H1", "H2", "H3", "H4", "L1", "L2", "L3", "L4", "L5"]
    for a, b in zip(order, order[1:]):
        assert P.PAYTABLE[a][4] >= P.PAYTABLE[b][4], (a, b)


def test_ladders_are_strictly_increasing_and_start_at_one():
    for name, ladder in P.LADDER.items():
        assert ladder[0] == 1, name
        assert all(b > a for a, b in zip(ladder, ladder[1:])), name


def test_win_levels_are_ascending_and_end_at_the_wincap():
    values = [v for _, v in sorted(P.WIN_LEVELS.items())]
    assert values == sorted(values)
    assert values[-1] == P.WINCAP


def test_distribution_quotas_add_up_to_one():
    q = P.BASE_MODE["quota"]
    assert sum(v for v in q.values() if v is not None) < 1.0
    assert P.BONUS_MODE["quota"]["wincap"] < 1.0
    assert P.WINCAP == 10000 and P.RTP == pytest.approx(0.96)


def test_free_spin_tables_award_more_for_more_scatters():
    for table in (P.FS_TRIGGER, P.FS_RETRIGGER):
        keys = sorted(table)
        assert keys == [3, 4, 5]
        assert all(table[a] < table[b] for a, b in zip(keys, keys[1:]))


# --------------------------------------------------------------------------- #
# reel strips
# --------------------------------------------------------------------------- #
def _strip(name):
    with open(os.path.join(REELS, f"{name}.csv")) as f:
        rows = list(csv.reader(f))
    return [[r[c] for r in rows] for c in range(P.NUM_REELS)]


@pytest.mark.parametrize("name", list(P.REEL_WEIGHTS))
def test_reel_strips_match_the_declared_shape(name):
    cols = _strip(name)
    assert len(cols) == P.NUM_REELS
    known = set(P.PAYING_SYMBOLS) | {P.WILD, P.SCATTER, P.KEG, P.ROCK}
    for reel, col in enumerate(cols):
        assert len(col) == P.STRIP_LENGTH
        assert set(col) <= known
        if reel == 0:
            assert P.WILD not in col, "wilds never land on reel 1"


def test_strips_are_reproducible():
    import build_reels

    fresh = build_reels.build_all(write=False)
    for name in P.REEL_WEIGHTS:
        assert fresh[name] == _strip(name), f"{name} differs from build_reels output - rerun build_reels.py"


# --------------------------------------------------------------------------- #
# independent evaluator + book replay
# --------------------------------------------------------------------------- #
def ways(board):
    """board: 5 columns of PADDED symbol names -> {symbol: (kind, ways)} (independent of the SDK)."""
    out = {}
    for sym in P.PAYING_SYMBOLS:
        counts = []
        for reel in range(P.NUM_REELS):
            c = sum(1 for r in range(1, P.NUM_ROWS + 1) if board[reel][r] in (sym, P.WILD))
            if c == 0:
                break
            counts.append(c)
        if len(counts) >= 4:
            out[sym] = (len(counts), math.prod(counts))
    return out


def tumble(board, new_symbols, exploding):
    gone = {(p["reel"], p["row"]) for p in exploding}
    out = []
    for reel in range(P.NUM_REELS):
        kept = [s for row, s in enumerate(board[reel]) if (reel, row) not in gone]
        out.append([s["name"] for s in new_symbols[reel]] + kept)
    return out


def _books(mode, limit):
    path = os.path.join(PUBLISH, f"books_{mode}.jsonl.zst")
    if not os.path.exists(path):
        pytest.skip("books not generated - run games/nitro_vein/run.py")
    zstandard = pytest.importorskip("zstandard")
    n = 0
    with open(path, "rb") as f:
        reader = io.TextIOWrapper(zstandard.ZstdDecompressor().stream_reader(f), encoding="utf-8")
        for line in reader:
            yield json.loads(line)
            n += 1
            if n >= limit:
                return


def replay(book):
    """Replay one book with the independent rules. Returns a list of problems."""
    problems = []
    events = book["events"]
    if events[0]["type"] != "reveal" or events[-1]["type"] != "finalWin":
        return ["book does not open with reveal / close with finalWin"]
    if any(e["type"] == "wincap" for e in events):
        return []  # the cap truncates the sequence on purpose
    if events[-1]["amount"] != book["payoutMultiplier"]:
        problems.append("finalWin != payoutMultiplier")
    if book["payoutMultiplier"] % 10:
        problems.append("payout is not a multiple of 0.1x")
    if book["payoutMultiplier"] > P.WINCAP * 100:
        problems.append("payout above the wincap")

    board = None
    game = None
    idx = 0
    running = 0
    for e in events:
        t = e["type"]
        if t == "reveal":
            board = [[s["name"] for s in col] for col in e["board"]]
            if e["gameType"] == "basegame" or game == "basegame":
                idx = 0  # base resets every spin; the first free spin starts a fresh ladder
            game = e["gameType"]
        elif t == "winInfo":
            expected = ways(board)
            got = {w["symbol"]: (w["kind"], w["meta"]["ways"]) for w in e["wins"]}
            if expected != got:
                problems.append(f"winInfo {got} != independent evaluator {expected}")
                return problems
            kegs = sum(col[r] == P.KEG for col in board for r in range(1, P.NUM_ROWS + 1))  # visible rows only
            table = P.LADDER["freegame" if game == "freegame" else "basegame"]
            mult = table[min(idx + kegs, len(table) - 1)]
            if e["ladder"]["multiplier"] != mult or e["ladder"]["kegs"] != kegs:
                problems.append(f"ladder {e['ladder']} != expected mult {mult} kegs {kegs} (idx {idx})")
                return problems
            step_total = 0
            for w in e["wins"]:
                per_way = P.PAYTABLE[w["symbol"]][w["kind"]] * P.PAYTABLE_SCALE
                base = round(per_way * w["meta"]["ways"] * 100)
                if abs(w["meta"]["winWithoutMult"] - base) > 1:
                    problems.append(f"winWithoutMult {w['meta']['winWithoutMult']} != {base}")
                step_total += w["win"]
            if abs(step_total - e["totalWin"]) > 0:
                problems.append("winInfo.totalWin != sum(wins)")
            running += e["totalWin"]
            idx = min(idx + 1 + kegs, len(table) - 1)
        elif t == "tumbleBoard":
            board = tumble(board, e["newSymbols"], e["explodingSymbols"])
            if any(len(col) != PADDED for col in board):
                problems.append("tumble left a column with the wrong height")
                return problems
        elif t == "updateTumbleWin":
            if e["amount"] < 0:
                problems.append("negative running win")
    return problems


@pytest.mark.parametrize("mode,limit", [("base", 6000), ("bonus", 1500)])
def test_books_replay_against_the_independent_rules(mode, limit):
    bad = []
    for book in _books(mode, limit):
        problems = replay(book)
        if problems:
            bad.append((book["id"], problems[0]))
    assert not bad, f"{len(bad)} books failed, first: {bad[:5]}"


def test_no_book_ends_with_a_winning_board():
    """Cascades must run until the board has no ways win left."""
    bad = []
    for book in _books("base", 3000):
        board = None
        for e in book["events"]:
            if e["type"] == "reveal":
                board = [[s["name"] for s in col] for col in e["board"]]
                # the board settles below; checked when the next reveal / the end arrives
            elif e["type"] == "tumbleBoard":
                board = tumble(board, e["newSymbols"], e["explodingSymbols"])
        if any(e["type"] == "wincap" for e in book["events"]):
            continue
        if board is not None and ways(board):
            bad.append(book["id"])
    assert not bad, f"books left with a winning board: {bad[:10]}"


def test_lookup_tables_match_the_books():
    for mode in ("base", "bonus"):
        lut = os.path.join(PUBLISH, f"lookUpTable_{mode}_0.csv")
        if not os.path.exists(lut):
            pytest.skip("LUT not generated")
        with open(lut) as f:
            rows = [tuple(map(int, r)) for r in csv.reader(f)]
        payouts = {}
        for book in _books(mode, 10**9 if mode == "bonus" else 20000):
            payouts[book["id"]] = book["payoutMultiplier"]
        for i, weight, payout in rows:
            if i in payouts:
                assert payouts[i] == payout, (mode, i)
            assert weight >= 0
