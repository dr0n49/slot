"""NITRO VEIN — single source of truth for every tunable math parameter.

Nothing in the frontend, the reel builder, the game-state code or the tests
hard-codes a math value: they all read this module (directly, or through the
generated `config_fe_nitro_vein.json`). To retune the game edit values here,
then run:

    python games/nitro_vein/build_reels.py      # rebuild reel strips from weights
    python games/nitro_vein/run.py              # simulate + optimise + publish

RTP is hit by the SDK optimiser, which re-weights the simulated books per
criteria (`CRITERIA` below). The paytable / reel weights only need to keep the
*natural* RTP of each criteria in the neighbourhood of its target share.
"""

GAME_ID = "nitro_vein"
GAME_NAME = "Nitro Vein"
PROVIDER_NUMBER = 0

# --------------------------------------------------------------------------- #
# Headline numbers
# --------------------------------------------------------------------------- #
RTP = 0.96  # target RTP of every bet mode
WINCAP = 10000  # max win, in multiples of the total bet (enforced by math, never by UI)
BONUS_COST = 100.0  # bonus-buy price, in multiples of the bet

# --------------------------------------------------------------------------- #
# Board
# --------------------------------------------------------------------------- #
NUM_REELS = 5
NUM_ROWS = 6
STRIP_LENGTH = 100  # rows per reel-strip csv

# --------------------------------------------------------------------------- #
# Symbols
#   L* = low gems, H* = high relics, W = wild (reels 2-5), S = scatter (dynamite),
#   K = nitro keg (special: detonates on any winning cascade and boosts the ladder)
# --------------------------------------------------------------------------- #
PAYING_SYMBOLS = ["H1", "H2", "H3", "H4", "L1", "L2", "L3", "L4", "L5"]
WILD = "W"
SCATTER = "S"
KEG = "K"
ROCK = "R"  # bedrock: never pays, never removed - it only takes up space (and falls with gravity)

# Ways pay: multiples of the total bet PER WAY, for 3 / 4 / 5 reels in a row
# (before PAYTABLE_SCALE is applied).
PAYTABLE_SCALE = 0.25  # single knob to move the whole natural RTP up / down
PAYTABLE = {
    "H1": {4: 1.60, 5: 5.00},
    "H2": {4: 1.20, 5: 4.00},
    "H3": {4: 0.80, 5: 2.60},
    "H4": {4: 0.60, 5: 1.80},
    "L1": {4: 0.28, 5: 0.80},
    "L2": {4: 0.22, 5: 0.64},
    "L3": {4: 0.18, 5: 0.50},
    "L4": {4: 0.14, 5: 0.40},
    "L5": {4: 0.12, 5: 0.32},
}

# Blast Ladder: multiplier applied to a cascade step's win. The ladder index
# climbs by one after every winning cascade step (+1 more per Nitro Keg that
# detonated). Base game resets each spin; free spins carry it across spins.
LADDER = {
    "basegame": [1, 2, 3, 5, 8, 12, 20, 30, 50, 100],
    "freegame": [1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30, 40, 50, 75, 100],
}

# --------------------------------------------------------------------------- #
# Free spins ("Deep Vein")
#   number of scatters on the board after the cascade sequence -> spins awarded
# --------------------------------------------------------------------------- #
FS_TRIGGER = {3: 8, 4: 12, 5: 16}
FS_RETRIGGER = {3: 4, 4: 6, 5: 8}
FS_MAX_SCATTER_COUNT = 5  # counts above this reuse the last table entry
ANTICIPATION_AT_SCATTERS = {"basegame": 2, "freegame": 2}

# --------------------------------------------------------------------------- #
# Reel strip weights (relative weights per strip of STRIP_LENGTH cells).
# Per-reel overrides allow e.g. "no wild on reel 1". Keys are symbol names.
# The strip builder turns these into exact integer counts.
# --------------------------------------------------------------------------- #
_BASE_WEIGHTS = {
    "H1": 4, "H2": 5, "H3": 7, "H4": 9,
    "L1": 11, "L2": 12, "L3": 13, "L4": 14, "L5": 15,
    "W": 3, "S": 2, "K": 3, "R": 28,
}

_FREE_WEIGHTS = {
    "H1": 4, "H2": 5, "H3": 7, "H4": 9,
    "L1": 11, "L2": 12, "L3": 13, "L4": 14, "L5": 15,
    "W": 4, "S": 1.5, "K": 4, "R": 26,
}

# Generous strips used only to hunt for max-win books.
_WINCAP_WEIGHTS = {
    "H1": 8, "H2": 9, "H3": 10, "H4": 10,
    "L1": 9, "L2": 9, "L3": 9, "L4": 9, "L5": 9,
    "W": 12, "S": 1.5, "K": 9, "R": 4,
}

REEL_WEIGHTS = {
    # strip name -> {reel index -> {symbol: weight}}
    "BR0": {r: dict(_BASE_WEIGHTS) for r in range(NUM_REELS)},
    "FR0": {r: dict(_FREE_WEIGHTS) for r in range(NUM_REELS)},
    "FRWCAP": {r: dict(_WINCAP_WEIGHTS) for r in range(NUM_REELS)},
}
# Wilds never land on the first reel (a ways win must start with a real symbol).
for _strip in REEL_WEIGHTS.values():
    _strip[0]["W"] = 0

# Minimum distance (in strip rows) between two symbols of the same "rare" kind.
MIN_SPACING = {"S": 8, "K": 4, "W": 3}

# --------------------------------------------------------------------------- #
# Win levels (thresholds in x bet, lower bound inclusive). The book carries the
# level integer; the frontend maps it to normal / big / mega / massive / max.
# --------------------------------------------------------------------------- #
WIN_LEVELS = {
    1: 0.0,
    2: 0.5,
    3: 2.0,
    4: 5.0,
    5: 10.0,
    6: 20.0,  # BIG
    7: 50.0,  # MEGA
    8: 200.0,  # MASSIVE
    9: 1000.0,  # MASSIVE (jackpot flourish)
    10: WINCAP,  # MAX WIN
}

# --------------------------------------------------------------------------- #
# Simulation criteria -> quotas / forced conditions and optimiser targets.
# rtp shares must add up to RTP (checked by the SDK).
# --------------------------------------------------------------------------- #
BASE_MODE = {
    "quota": {"wincap": 0.0008, "freegame": 0.1, "0": 0.4, "basegame": None},  # None = remainder
    "scatter_triggers": {3: 100, 4: 20, 5: 4},
    "rtp_share": {"wincap": 0.001, "freegame": 0.36, "0": 0.0, "basegame": None},  # None = remainder
    "hit_rate": {"freegame": 190, "basegame": 3.2},
}
BONUS_MODE = {
    "quota": {"wincap": 0.002, "freegame": None},
    "scatter_triggers": {3: 100, 4: 30, 5: 8},
    "rtp_share": {"wincap": 0.001, "freegame": None},
}

# Optimiser search parameters (see SDK docs). Larger = slower but smoother.
OPTIMISER = {"num_show": 5000, "num_per_fence": 10000, "sim_trials": 5000}

# Default simulation sizes used by run.py (override on the CLI).
DEFAULT_SIMS = {"base": 200_000, "bonus": 40_000}
