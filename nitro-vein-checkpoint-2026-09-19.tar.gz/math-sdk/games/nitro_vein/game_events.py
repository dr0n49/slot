"""Game specific book events (in addition to the SDK's standard events)."""

from copy import deepcopy

from src.events.events import json_ready_sym

UPDATE_LADDER = "updateLadder"
KEG_BLAST = "kegBlast"


def _pad(pos: dict, gamestate) -> dict:
    """Book positions are relative to the padded board (row 0 = hidden top symbol)."""
    offset = 1 if gamestate.config.include_padding else 0
    return {"reel": pos["reel"], "row": pos["row"] + offset}


def _cents(value: float, cap: float) -> int:
    return int(round(min(value, cap) * 100, 0))


def win_info_ways_event(gamestate, win_data: dict, ladder_index: int, multiplier: int, kegs: int) -> None:
    """One cascade step: every symbol that paid, its ways, and the ladder multiplier applied."""
    cap = gamestate.config.wincap
    wins = []
    for win in win_data["wins"]:
        wins.append(
            {
                "symbol": win["symbol"],
                "kind": win["kind"],
                "win": _cents(win["win"], cap),
                "positions": [_pad(p, gamestate) for p in win["positions"]],
                "meta": {
                    "ways": win["meta"]["ways"],
                    "globalMult": multiplier,
                    "winWithoutMult": _cents(win["meta"]["winWithoutMult"], cap),
                },
            }
        )
    gamestate.book.add_event(
        {
            "index": len(gamestate.book.events),
            "type": "winInfo",
            "totalWin": _cents(win_data["totalWin"], cap),
            "wins": wins,
            "ladder": {"index": ladder_index, "multiplier": multiplier, "kegs": kegs},
        }
    )


def keg_blast_event(gamestate, positions: list, from_index: int, to_index: int, multiplier: int) -> None:
    """Nitro kegs detonate with a winning step and push the ladder up before the win is paid."""
    gamestate.book.add_event(
        {
            "index": len(gamestate.book.events),
            "type": KEG_BLAST,
            "positions": [_pad(p, gamestate) for p in positions],
            "fromIndex": from_index,
            "toIndex": to_index,
            "multiplier": multiplier,
        }
    )


def update_ladder_event(gamestate) -> None:
    """Announce the multiplier the NEXT winning cascade step will use."""
    ladder = gamestate.config.ladder[gamestate.gametype]
    idx = gamestate.ladder_index
    gamestate.book.add_event(
        {
            "index": len(gamestate.book.events),
            "type": UPDATE_LADDER,
            "ladderIndex": idx,
            "multiplier": ladder[idx],
            "steps": len(ladder),
        }
    )


def tumble_board_all_event(gamestate, exploding: list) -> None:
    """Every symbol removed this step (winning symbols + detonated kegs) and what falls in."""
    special_attributes = list(gamestate.config.special_symbols.keys())
    new_symbols = [[] for _ in range(gamestate.config.num_reels)]
    for reel, syms in enumerate(gamestate.new_symbols_from_tumble):
        if syms:
            new_symbols[reel] = [json_ready_sym(s, special_attributes) for s in syms]
    exploding_sorted = sorted(
        ({"reel": p["reel"], "row": p["row"] + (1 if gamestate.config.include_padding else 0)} for p in exploding),
        key=lambda p: (p["reel"], p["row"]),
    )
    gamestate.book.add_event(
        {
            "index": len(gamestate.book.events),
            "type": "tumbleBoard",
            "newSymbols": new_symbols,
            "explodingSymbols": deepcopy(exploding_sorted),
        }
    )
