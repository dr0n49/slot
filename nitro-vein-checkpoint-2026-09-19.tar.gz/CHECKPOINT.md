# NITRO VEIN — checkpoint 2026-09-19

Unpack in ~/slot so the folders merge:  tar xzf nitro-vein-checkpoint-2026-09-19.tar.gz -C ~/slot
  -> math-sdk/games/nitro_vein   (math, tests, reels)   -> `python games/nitro_vein/run.py` regenerates the books
  -> web-sdk/apps/nitro-vein     (frontend)             -> see its README.md (pnpm install; pnpm --filter pixi-svelte build; pnpm --filter nitro-vein dev:mock)

## Done and verified
- Math: RTP 0.96 (base + bonus), wincap 10000x, payouts in 0.1x steps; 13 pytest tests incl. independent replay of books.
- Frontend builds, svelte-check clean for the app, vitest tests green.
- Browser QA (Playwright, mock RGS): spin/cascade/keg, free spins intro/outro, big/mega/massive/max win, buy bonus, info, autoplay start/stop,
  turbo, skip, reload-mid-round resume, failed spin / invalid book / insufficient balance / dropped session -> error dialog + clean IDLE.
- Desktop 1280x720 and portrait 390x844 layouts checked.

## Still to do
- Re-shoot big-win tier timing after the segmented count-up change (BIG -> MEGA -> MASSIVE) and check the "x" glyph in the display font.
- Tablet layouts (1024x768, 768x1024) visual check; keg-blast / ladder highlight polish.
- Final polish pass, full re-run of tests, then final delivery.
