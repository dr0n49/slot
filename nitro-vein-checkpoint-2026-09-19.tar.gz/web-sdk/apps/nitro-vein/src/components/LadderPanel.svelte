<script lang="ts">
	import { stateGame } from '../game/stateGame.svelte';

	type Props = { portrait: boolean; width: number; top: number; height: number };
	const { portrait, width, top, height }: Props = $props();

	const values = $derived(stateGame.ladderValues);
	const idx = $derived(stateGame.ladderIndex);
	const current = $derived(values[Math.min(idx, values.length - 1)] ?? 1);
	const paid = $derived(stateGame.ladderPayMultiplier);
	/** rungs shown top→bottom (highest first) in the rail */
	const rungs = $derived(values.map((v, i) => ({ v, i })).reverse());
	const boosted = $derived(stateGame.ladderBoost > 0);
</script>

{#if !portrait}
	<aside class="rail" style="left: 12px; top: {top}px; width: {width - 24}px; height: {height}px" aria-label="Blast Ladder">
		<div class="title">BLAST LADDER</div>
		<ol class="rungs" data-testid="ladder">
			{#each rungs as r (r.i)}
				<li class:done={r.i < idx} class:current={r.i === idx} class:top={r.i === values.length - 1}>
					<span class="dot"></span><span class="v">×{r.v}</span>
				</li>
			{/each}
		</ol>
		<div class="foot">
			<span class="cur" data-testid="ladder-current">×{current}</span>
			<span class="hint">NEXT WIN</span>
			{#if boosted}<span class="keg">TNT +{stateGame.ladderBoost}</span>{/if}
		</div>
	</aside>
{:else}
	<aside class="strip" style="top: {top}px; height: {height}px" aria-label="Blast Ladder">
		<div class="lbl">BLAST<br />LADDER</div>
		<div class="track" data-testid="ladder">
			{#each values as v, i (i)}
				<span class="pip" class:done={i < idx} class:current={i === idx}>
					{#if i === idx}<b>×{v}</b>{/if}
				</span>
			{/each}
		</div>
		<div class="now">
			<span class="cur" data-testid="ladder-current">×{current}</span>
			{#if boosted}<span class="keg">TNT +{stateGame.ladderBoost}</span>{/if}
		</div>
	</aside>
{/if}
<span class="sr" aria-live="polite">Multiplier {paid}</span>

<style>
	.rail {
		position: absolute;
		display: flex;
		flex-direction: column;
		align-items: stretch;
		padding: 10px 8px 8px;
		box-sizing: border-box;
		border: 2px solid rgba(255, 213, 74, 0.4);
		border-radius: 16px;
		background: linear-gradient(180deg, rgba(38, 22, 53, 0.92), rgba(14, 8, 22, 0.92));
		box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
		z-index: 12;
	}
	.title {
		margin-bottom: 6px;
		text-align: center;
		font-family: var(--nv-font-display);
		font-size: 17px;
		letter-spacing: 0.12em;
		color: var(--nv-gold);
		text-shadow: var(--nv-text-shadow);
	}
	.rungs {
		flex: 1 1 auto;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		margin: 0;
		padding: 0;
		list-style: none;
		min-height: 0;
	}
	.rungs li {
		display: flex;
		align-items: center;
		gap: 10px;
		flex: 1 1 0;
		min-height: 0;
		padding: 0 12px;
		border-radius: 8px;
		color: rgba(255, 243, 196, 0.42);
		font-family: var(--nv-font-display);
		font-size: clamp(11px, 2.6vh, 20px);
		letter-spacing: 0.06em;
		transition: background 0.2s, color 0.2s, transform 0.2s;
	}
	.dot {
		width: 9px;
		height: 9px;
		border-radius: 50%;
		background: rgba(255, 213, 74, 0.25);
		flex: none;
	}
	.rungs li.done {
		color: rgba(255, 213, 74, 0.7);
	}
	.rungs li.done .dot {
		background: var(--nv-gold);
	}
	.rungs li.current {
		background: linear-gradient(90deg, rgba(255, 106, 26, 0.85), rgba(255, 193, 7, 0.75));
		color: #fff;
		transform: scale(1.06);
		box-shadow: 0 0 18px rgba(255, 150, 30, 0.85);
		animation: rung-pop 0.45s ease-out;
	}
	.rungs li.current .dot {
		background: #fff;
		box-shadow: 0 0 8px #fff;
	}
	.rungs li.top:not(.current) {
		color: rgba(255, 179, 0, 0.7);
	}
	.foot {
		display: flex;
		flex-direction: column;
		align-items: center;
		margin-top: 6px;
		padding-top: 6px;
		border-top: 1px solid rgba(255, 213, 74, 0.25);
	}
	.cur {
		font-family: var(--nv-font-display);
		font-size: 34px;
		line-height: 1;
		color: #fff;
		text-shadow: 0 2px 0 #000, 0 0 16px rgba(255, 150, 30, 0.9);
	}
	.hint {
		font-size: 10px;
		letter-spacing: 0.2em;
		color: #ff9a2e;
		font-weight: 700;
	}
	.keg {
		margin-top: 4px;
		padding: 1px 8px;
		border-radius: 999px;
		background: #d81f1f;
		color: #fff;
		font-family: var(--nv-font-display);
		font-size: 13px;
		letter-spacing: 0.08em;
		animation: rung-pop 0.5s ease-out;
	}
	@keyframes rung-pop {
		0% {
			transform: scale(1.35);
			filter: brightness(1.7);
		}
		100% {
			transform: scale(1.06);
			filter: none;
		}
	}

	.strip {
		position: absolute;
		left: 14px;
		right: 14px;
		display: grid;
		grid-template-columns: auto 1fr auto;
		align-items: center;
		gap: 10px;
		padding: 0 12px;
		border: 2px solid rgba(255, 213, 74, 0.4);
		border-radius: 14px;
		background: linear-gradient(180deg, rgba(38, 22, 53, 0.92), rgba(14, 8, 22, 0.92));
		z-index: 12;
	}
	.lbl {
		font-family: var(--nv-font-display);
		font-size: 13px;
		line-height: 1.05;
		letter-spacing: 0.1em;
		color: var(--nv-gold);
	}
	.track {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 3px;
	}
	.pip {
		flex: 1 1 0;
		height: 12px;
		max-width: 26px;
		border-radius: 4px;
		background: rgba(255, 213, 74, 0.18);
		display: flex;
		align-items: center;
		justify-content: center;
		position: relative;
	}
	.pip.done {
		background: var(--nv-gold);
	}
	.pip.current {
		background: linear-gradient(180deg, #ff8a2e, #ff6a1a);
		height: 22px;
		box-shadow: 0 0 12px rgba(255, 150, 30, 0.9);
		animation: rung-pop 0.45s ease-out;
	}
	.pip.current b {
		position: absolute;
		top: -20px;
		font-family: var(--nv-font-display);
		font-size: 14px;
		color: #fff;
		white-space: nowrap;
		text-shadow: 0 2px 0 #000;
	}
	.now {
		display: flex;
		flex-direction: column;
		align-items: center;
	}
	.strip .cur {
		font-size: 30px;
	}
	.sr {
		position: absolute;
		width: 1px;
		height: 1px;
		overflow: hidden;
		clip: rect(0 0 0 0);
	}
</style>
