<script lang="ts">
	type Props = {
		label: string;
		value: string;
		align?: 'left' | 'right' | 'center';
		pulse?: boolean;
		testid?: string;
	};

	const props: Props = $props();
</script>

<div class="stat {props.align ?? 'left'}" class:pulse={props.pulse}>
	<span class="label">{props.label}</span>
	<span class="value" data-testid={props.testid}>{props.value}</span>
</div>

<style>
	.stat {
		display: flex;
		flex-direction: column;
		gap: 0;
		min-width: 0;
	}
	.stat.left {
		align-items: flex-start;
		text-align: left;
	}
	.stat.right {
		align-items: flex-end;
		text-align: right;
	}
	.stat.center {
		align-items: center;
		text-align: center;
	}
	.label {
		color: #ff9a2e;
		font-family: var(--nv-font-ui);
		font-size: 12px;
		font-weight: 700;
		letter-spacing: 0.16em;
		text-transform: uppercase;
		text-shadow: 0 1px 0 #000;
	}
	.value {
		max-width: 100%;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		color: var(--nv-cream);
		font-family: var(--nv-font-display);
		font-size: 34px;
		line-height: 1.05;
		letter-spacing: 0.02em;
		text-shadow: var(--nv-text-shadow);
		font-variant-numeric: tabular-nums;
	}
	.pulse .value {
		animation: stat-pulse 0.5s ease-in-out infinite alternate;
	}
	@keyframes stat-pulse {
		from {
			color: var(--nv-cream);
		}
		to {
			color: #fff;
			text-shadow:
				0 2px 0 #000,
				0 0 22px rgba(255, 213, 74, 0.9);
		}
	}
	:global(.nv-stage.portrait) .value {
		font-size: 30px;
	}
</style>
