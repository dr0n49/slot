<script lang="ts">
	import { stateBet, stateBetDerived } from 'state-shared';

	import { sfx } from '../../game/sfx';
	import { getContext } from '../../game/context';
	import { betAmountIndex, formatBetLabel, resolvedBetAmountOptions } from '../../game/constants';

	type Props = { disabled?: boolean };
	const { disabled = false }: Props = $props();

	const context = getContext();
	let open = $state(false);

	const betOptions = $derived(resolvedBetAmountOptions());
	const currentIdx = $derived(betAmountIndex(stateBet.betAmount, betOptions));
	const atMin = $derived(currentIdx <= 0);
	const atMax = $derived(currentIdx >= betOptions.length - 1);

	const setBet = (amount: number) => {
		sfx.unlock();
		sfx.play('bet_change');
		context.eventEmitter.broadcast({ type: 'soundPressGeneral' });
		stateBetDerived.setBetAmount(amount);
		open = false;
	};
	const stepUp = () => {
		if (disabled || atMax) return;
		setBet(betOptions[currentIdx + 1]);
	};
	const stepDown = () => {
		if (disabled || atMin) return;
		setBet(betOptions[currentIdx - 1]);
	};
	const toggleOpen = () => {
		if (disabled) return;
		sfx.click();
		open = !open;
	};
	const onWindowClick = (event: MouseEvent) => {
		if (!(event.target as HTMLElement).closest('.bet-selector')) open = false;
	};
</script>

<svelte:window onclick={onWindowClick} />

<div class="bet-selector">
	<button type="button" class="step" aria-label="Lower bet" disabled={disabled || atMin} onclick={stepDown}>
		<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 9h14l-7 8-7-8Z" /></svg>
	</button>

	<div class="picker">
		<button
			type="button"
			class="value"
			data-testid="bet-value"
			{disabled}
			aria-expanded={open}
			aria-haspopup="listbox"
			onclick={toggleOpen}
		>
			<span class="label">BET</span>
			<span class="amount">{formatBetLabel(stateBet.betAmount)}</span>
		</button>

		{#if open}
			<ul class="menu" role="listbox" aria-label="Bet amount">
				{#each betOptions as amount (amount)}
					<li role="option" aria-selected={amount === stateBet.betAmount}>
						<button type="button" class:selected={amount === stateBet.betAmount} onclick={() => setBet(amount)}>
							{formatBetLabel(amount)}
						</button>
					</li>
				{/each}
			</ul>
		{/if}
	</div>

	<button type="button" class="step" aria-label="Raise bet" disabled={disabled || atMax} onclick={stepUp}>
		<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 15h14l-7-8-7 8Z" /></svg>
	</button>
</div>

<style>
	.bet-selector {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		position: relative;
	}
	.step {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 44px;
		height: 44px;
		padding: 0;
		border: 2px solid #8b6914;
		border-radius: 50%;
		background: linear-gradient(180deg, #ffe680 0%, #ffc107 55%, #b8860b 100%);
		box-shadow:
			inset 0 1px 0 rgba(255, 255, 255, 0.5),
			0 3px 5px rgba(0, 0, 0, 0.5);
		color: #2a1400;
		cursor: pointer;
		transition: filter 0.12s ease, transform 0.08s ease;
	}
	.step svg {
		width: 24px;
		height: 24px;
		fill: currentColor;
	}
	.step:hover:not(:disabled) {
		filter: brightness(1.1);
	}
	.step:active:not(:disabled) {
		transform: translateY(2px);
	}
	.step:disabled {
		opacity: 0.35;
		cursor: not-allowed;
	}
	.step:focus-visible,
	.value:focus-visible,
	.menu button:focus-visible {
		outline: 3px solid var(--nv-cyan);
		outline-offset: 2px;
	}
	.picker {
		position: relative;
	}
	.value {
		display: flex;
		flex-direction: column;
		align-items: center;
		min-width: 104px;
		padding: 2px 12px 3px;
		border: 2px solid rgba(255, 213, 74, 0.45);
		border-radius: 12px;
		background: linear-gradient(180deg, rgba(10, 4, 18, 0.9), rgba(30, 16, 44, 0.9));
		box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.7);
		cursor: pointer;
	}
	.value:disabled {
		cursor: not-allowed;
		opacity: 0.6;
	}
	.label {
		color: #ff9a2e;
		font-family: var(--nv-font-ui);
		font-size: 11px;
		font-weight: 700;
		letter-spacing: 0.2em;
	}
	.amount {
		color: var(--nv-cream);
		font-family: var(--nv-font-display);
		font-size: 28px;
		line-height: 1;
		text-shadow: var(--nv-text-shadow);
	}
	.menu {
		position: absolute;
		bottom: calc(100% + 8px);
		left: 50%;
		z-index: 60;
		transform: translateX(-50%);
		margin: 0;
		padding: 6px;
		list-style: none;
		width: max-content;
		min-width: 110px;
		max-height: 260px;
		overflow-y: auto;
		border: 2px solid #8b6914;
		border-radius: 12px;
		background: linear-gradient(180deg, #2a1740 0%, #0f0818 100%);
		box-shadow: 0 8px 24px rgba(0, 0, 0, 0.65);
	}
	.menu button {
		display: block;
		width: 100%;
		padding: 8px 14px;
		border: none;
		border-radius: 8px;
		background: transparent;
		color: var(--nv-gold);
		font-family: var(--nv-font-display);
		font-size: 20px;
		text-align: center;
		cursor: pointer;
	}
	.menu button:hover,
	.menu button.selected {
		background: rgba(255, 213, 74, 0.18);
		color: #fff;
	}
</style>
