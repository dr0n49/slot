<script lang="ts">
	import { stateBet } from 'state-shared';

	import { formatAmount, formatBookWin } from '../../game/constants';
	import { stateGame } from '../../game/stateGame.svelte';
	import BetSelector from './BetSelector.svelte';
	import StatDisplay from './StatDisplay.svelte';

	type Props = { betDisabled: boolean };
	const { betDisabled }: Props = $props();

	const winDisplay = $derived(formatBookWin(stateGame.displayWin));
	const credits = $derived(formatAmount(stateBet.balanceAmount));
</script>

<div class="stats-row">
	<div class="win">
		<StatDisplay label="WIN" value={winDisplay} align="left" pulse={stateGame.winCounting} testid="win-value" />
	</div>
	<div class="bet"><BetSelector disabled={betDisabled} /></div>
	<div class="credits">
		<StatDisplay label="BALANCE" value={credits} align="right" testid="balance-value" />
	</div>
</div>

<style>
	.stats-row {
		display: grid;
		grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
		align-items: center;
		gap: 14px;
		min-width: 0;
	}
	:global(.nv-stage.portrait) .stats-row {
		grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
		grid-template-areas:
			'win credits'
			'bet bet';
		row-gap: 6px;
	}
	:global(.nv-stage.portrait) .win {
		grid-area: win;
	}
	:global(.nv-stage.portrait) .credits {
		grid-area: credits;
	}
	:global(.nv-stage.portrait) .bet {
		grid-area: bet;
		justify-self: center;
	}
</style>
