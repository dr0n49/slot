<script lang="ts">
	import { getContext } from '../../game/context';
	import { stateGame } from '../../game/stateGame.svelte';
	import ControlPanel from './ControlPanel.svelte';
	import StatsBar from './StatsBar.svelte';

	type Props = { height: number };
	const { height }: Props = $props();

	const context = getContext();
	const betDisabled = $derived(
		!(stateGame.sceneReady && context.stateXstateDerived.isIdle() && stateGame.phase === 'IDLE') ||
			context.stateXstateDerived.isAutoBetting(),
	);
</script>

<div class="hud" style="height: {height}px">
	<StatsBar {betDisabled} />
	<ControlPanel />
</div>

<style>
	.hud {
		position: absolute;
		left: 0;
		right: 0;
		bottom: 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		gap: 6px;
		padding: 8px 28px 10px;
		box-sizing: border-box;
		border-top: 3px solid var(--nv-gold-dark);
		background:
			linear-gradient(180deg, rgba(255, 213, 74, 0.1), transparent 30%),
			linear-gradient(180deg, #241533 0%, #120a1c 100%);
		box-shadow: 0 -8px 24px rgba(0, 0, 0, 0.55);
		pointer-events: auto;
		z-index: 20;
	}
	/* landscape: one compact row - WIN | tools | bet | SPIN | auto/buy | BALANCE */
	:global(.nv-stage:not(.portrait)) .hud {
		display: grid;
		grid-template-columns: minmax(0, 1fr) auto auto auto auto minmax(0, 1fr);
		grid-template-areas: 'win left bet spin right credits';
		align-items: center;
		column-gap: 16px;
		padding: 6px 28px 8px;
	}
	:global(.nv-stage:not(.portrait)) .hud :global(.stats-row),
	:global(.nv-stage:not(.portrait)) .hud :global(.controls) {
		display: contents;
	}
	:global(.nv-stage:not(.portrait)) .hud :global(.win) {
		grid-area: win;
	}
	:global(.nv-stage:not(.portrait)) .hud :global(.bet) {
		grid-area: bet;
	}
	:global(.nv-stage:not(.portrait)) .hud :global(.credits) {
		grid-area: credits;
	}
	:global(.nv-stage:not(.portrait)) .hud :global(.cluster.left) {
		grid-area: left;
	}
	:global(.nv-stage:not(.portrait)) .hud :global(.cluster.right) {
		grid-area: right;
	}
	:global(.nv-stage:not(.portrait)) .hud :global(.spin) {
		grid-area: spin;
	}
	:global(.nv-stage.portrait) .hud {
		padding: 8px 14px 12px;
		gap: 4px;
		justify-content: flex-start;
	}
</style>
