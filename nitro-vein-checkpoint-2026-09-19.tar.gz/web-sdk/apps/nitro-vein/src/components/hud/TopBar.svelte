<script lang="ts">
	import { stateSound } from 'state-shared';

	import { sfx } from '../../game/sfx';
	import { stateGame } from '../../game/stateGame.svelte';
	import { ICONS } from './icons';

	type Props = { height: number; portrait: boolean };
	const { height, portrait }: Props = $props();

	const muted = $derived(stateSound.volumeValueMaster === 0);
	let lastVolume = 75;
	const toggleMute = () => {
		sfx.unlock();
		if (stateSound.volumeValueMaster > 0) {
			lastVolume = stateSound.volumeValueMaster;
			stateSound.volumeValueMaster = 0;
		} else {
			stateSound.volumeValueMaster = lastVolume || 75;
		}
		sfx.applyVolumes();
		sfx.play('ui_toggle');
	};
	$effect(() => {
		// follow the settings-modal sliders
		void stateSound.volumeValueMaster;
		void stateSound.volumeValueMusic;
		void stateSound.volumeValueSoundEffect;
		sfx.applyVolumes();
	});
</script>

<div class="top" style="height: {height}px" class:portrait>
	<div class="logo" aria-label="Nitro Vein">
		<span class="n">NITRO</span><span class="v">VEIN</span>
	</div>
	{#if stateGame.fsActive}
		<div class="fs" data-testid="fs-counter">
			<span class="k">FREE SPINS</span>
			<span class="n">{stateGame.fsCurrent}<i>/</i>{stateGame.fsTotal}</span>
		</div>
	{/if}
	<button type="button" class="mute" onclick={toggleMute} aria-label={muted ? 'Unmute' : 'Mute'} aria-pressed={muted}>
		<svg viewBox="0 0 24 24" aria-hidden="true"><path d={muted ? ICONS.mute : ICONS.sound} /></svg>
	</button>
</div>

<style>
	.top {
		position: absolute;
		left: 0;
		right: 0;
		top: 0;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 22px;
		box-sizing: border-box;
		pointer-events: none;
		z-index: 15;
	}
	.top.portrait {
		padding: 0 14px;
		align-items: flex-start;
		padding-top: 14px;
	}
	.logo {
		display: flex;
		align-items: baseline;
		gap: 8px;
		font-family: var(--nv-font-display);
		font-size: 34px;
		line-height: 1;
		letter-spacing: 0.06em;
	}
	.logo .n {
		background: linear-gradient(180deg, #fff3a0, #ffc107 55%, #b8700a);
		-webkit-background-clip: text;
		background-clip: text;
		color: transparent;
		filter: drop-shadow(0 3px 0 rgba(0, 0, 0, 0.7));
	}
	.logo .v {
		background: linear-gradient(180deg, #ffb27a, #ff5a1a 55%, #a01a05);
		-webkit-background-clip: text;
		background-clip: text;
		color: transparent;
		filter: drop-shadow(0 3px 0 rgba(0, 0, 0, 0.7));
	}
	.portrait .logo {
		font-size: 30px;
	}
	.fs {
		display: flex;
		align-items: center;
		gap: 10px;
		padding: 6px 16px;
		border: 2px solid var(--nv-ember);
		border-radius: 999px;
		background: linear-gradient(180deg, #5a1408, #2a0806);
		box-shadow: 0 0 18px rgba(255, 106, 26, 0.6);
		font-family: var(--nv-font-display);
		color: #fff;
		letter-spacing: 0.08em;
	}
	.fs .k {
		font-family: var(--nv-font-ui);
		font-size: 12px;
		font-weight: 700;
		color: #ffb27a;
	}
	.fs .n {
		font-size: 26px;
		line-height: 1;
	}
	.fs i {
		font-style: normal;
		opacity: 0.6;
		padding: 0 2px;
	}
	.portrait .fs {
		position: absolute;
		left: 50%;
		bottom: 8px;
		transform: translateX(-50%);
		padding: 3px 14px;
	}
	.mute {
		pointer-events: auto;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 44px;
		height: 44px;
		padding: 0;
		border: 2px solid rgba(255, 213, 74, 0.45);
		border-radius: 50%;
		background: rgba(18, 10, 28, 0.75);
		color: var(--nv-gold);
		cursor: pointer;
	}
	.mute svg {
		width: 22px;
		height: 22px;
		fill: currentColor;
	}
	.mute:focus-visible {
		outline: 3px solid var(--nv-cyan);
		outline-offset: 2px;
	}
</style>
