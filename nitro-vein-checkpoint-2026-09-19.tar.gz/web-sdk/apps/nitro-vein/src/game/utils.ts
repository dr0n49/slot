import { stateBet } from 'state-shared';
import { createPlayBookUtils } from 'utils-book';
import { PUBLIC_CHROMATIC } from 'envs';

import { foldBoard } from './boardLogic';
import { bookEventHandlerMap } from './bookEventHandlerMap';
import { getScene } from './engine/scene';
import { eventEmitter } from './eventEmitter';
import { endRound, recoverFromError } from './roundFlow';
import { stateGame } from './stateGame.svelte';
import type { Bet, BookEvent } from './typesBookEvent';

export const { playBookEvent, playBookEvents } = createPlayBookUtils({ bookEventHandlerMap });

/**
 * A book must open with a reveal and close with a finalWin. Anything else is an invalid
 * response — we refuse to animate a half book (that would show a fake / partial outcome).
 */
export const validateBook = (events: unknown): events is BookEvent[] => {
	if (!Array.isArray(events) || events.length === 0) return false;
	const first = events[0] as BookEvent;
	const last = events[events.length - 1] as BookEvent;
	return first?.type === 'reveal' && last?.type === 'finalWin';
};

/** Instant application of already-played events (resume of a finished / partly played round). */
export const applyEventsInstant = (events: BookEvent[]) => {
	const names = foldBoard(events);
	let total = 0;
	for (const e of events) {
		if (e.type === 'setTotalWin' || e.type === 'finalWin' || e.type === 'wincap') total = e.amount;
	}
	stateBet.winBookEventAmount = total;
	stateGame.totalWin = total;
	stateGame.displayWin = total;
	const apply = () => {
		const scene = getScene();
		if (scene && names) scene.board.setBoard(names.map((col) => col.map((name) => ({ name }))));
	};
	if (getScene()) apply();
	else {
		// scene still loading — apply as soon as it is there
		const timer = setInterval(() => {
			if (getScene()) {
				clearInterval(timer);
				apply();
			}
		}, 100);
		setTimeout(() => clearInterval(timer), 15000);
	}
};

const payoutMatchesLocked = (bet: Bet) => {
	const locked = bet.payoutMultiplier ?? 0;
	const uiX = stateBet.winBookEventAmount / 100;
	if (locked > 0 && Math.abs(uiX - locked) > 0.011 && Math.abs(uiX - locked / 100) > 0.011) {
		console.error('[nitro-vein] displayed win diverged from the locked payout', { uiX, locked });
	}
};

export const playBet = async (bet: Bet & { id?: number }) => {
	stateGame.lockedPayoutMultiplier = bet.payoutMultiplier ?? 0;
	if (PUBLIC_CHROMATIC) {
		stateGame.sourceLabel = `Generated book${bet.id != null ? ` id ${bet.id}` : ''} — payoutMultiplier ${bet.payoutMultiplier}`;
	}
	if (!validateBook(bet.state)) {
		// Nothing sensible can be shown: recover, then let the engine close the round (end-round).
		recoverFromError('Invalid round data received from the server.');
		await endRound();
		eventEmitter.broadcast({ type: 'stopButtonEnable' });
		return;
	}
	try {
		await playBookEvents(bet.state);
		payoutMatchesLocked(bet);
	} catch (error) {
		recoverFromError('The round could not be displayed.', bet.state);
		console.error(error);
	}
	await endRound();
	eventEmitter.broadcast({ type: 'stopButtonEnable' });
};

/**
 * Resume from `/bet/event` index only. Replays the remaining events; never changes the payout
 * or any book outcome. Events before the resume index are applied instantly.
 */
export const convertTorResumableBet = (betToResume: Bet) => {
	const resumingIndex = Number(betToResume.event);
	if (!betToResume.event || Number.isNaN(resumingIndex)) return betToResume;
	const before = betToResume.state.filter((_, i) => i < resumingIndex);
	const after = betToResume.state.filter((_, i) => i >= resumingIndex);
	applyEventsInstant(before);
	return { ...betToResume, state: after };
};
