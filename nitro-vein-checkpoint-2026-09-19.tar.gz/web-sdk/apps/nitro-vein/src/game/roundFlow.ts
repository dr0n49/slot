import { stateBet } from 'state-shared';

import { foldBoard } from './boardLogic';
import { getScene } from './engine/scene';
import { scheduler } from './engine/tween';
import { clearPopups, clearSkip, fastMode, setWinInstant, syncTiming } from './presentation';
import { sfx } from './sfx';
import { setPhase, stateGame, stateGameDerived } from './stateGame.svelte';
import type { BookEvent } from './typesBookEvent';

/** Reels start moving the instant the bet is placed (before the RGS answered). */
export const beginSpin = async () => {
	syncTiming();
	setPhase('SPINNING');
	clearPopups();
	sfx.unlock();
	sfx.play('spin_start');
	sfx.startLoop('spin_loop');
	const scene = getScene();
	if (!scene) return;
	scene.board.clearHighlights();
	await scene.board.startSpin(fastMode());
};

/** Round finished normally: settle the phase machine back to IDLE. */
export const endRound = async () => {
	sfx.stopAllLoops();
	clearSkip();
	// already back at IDLE (an error recovery got there first): nothing left to settle
	if (stateGame.phase === 'IDLE') return;
	setPhase('COMPLETE');
	await new Promise((r) => setTimeout(r, stateBet.isTurbo ? 0 : 120));
	setPhase('IDLE');
};

/**
 * Something went wrong (failed spin, invalid response, presentation crash). Never leaves the
 * game stuck: stop animations, restore a valid board and return to IDLE so the player can
 * spin again. The RGS round itself is closed by the engine's end-round call.
 */
export const recoverFromError = (message: string, events?: readonly BookEvent[]) => {
	console.error('[nitro-vein] recovering:', message);
	scheduler.cancelAll();
	sfx.stopAllLoops();
	const scene = getScene();
	if (scene) {
		const names = events ? foldBoard(events) : null;
		try {
			if (names) {
				scene.board.setBoard(names.map((col) => col.map((name) => ({ name }))));
			} else if (scene.board.names.length) {
				// restore the last known board (a spin that never resolved must not leave blank reels)
				scene.board.setBoard(scene.board.names.map((col) => col.map((name) => ({ name }))));
			} else {
				scene.board.showIdle();
			}
		} catch (error) {
			console.error(error);
			scene.board.showIdle();
		}
		void scene.setFeatureMode(false);
	}
	stateGame.error = { message };
	stateGameDerived.recover();
	setWinInstant(stateGame.displayWin);
	syncTiming();
};
