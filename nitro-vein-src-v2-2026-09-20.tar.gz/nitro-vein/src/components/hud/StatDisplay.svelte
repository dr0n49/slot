<script lang="ts">
	type Props = {
		label: string;
		value: string;
		align?: 'left' | 'right' | 'center';
		pulse?: boolean;
		testid?: string;
	};

	const props: Props = $props();
</script>

<div class="stat {props.align ?? 'left'}" class:pulse={props.pulse}>
	<span class="line">
		<span class="label">{props.label}</span>
		<span class="value" data-testid={props.testid}>{props.value}</span>
	</span>
</div>

<style>
	.stat {
		min-width: 0;
	}
	.stat.left {
		text-align: left;
	}
	.stat.right {
		text-align: right;
	}
	.stat.center {
		text-align: center;
	}
	.line {
		display: inline-flex;
		align-items: baseline;
		gap: 8px;
		max-width: 100%;
	}
	.label,
	.value {
		font-family: var(--nv-font-hud);
		font-weight: 900;
		letter-spacing: 0.06em;
		text-transform: uppercase;
		-webkit-text-stroke: 1px #7a1a00;
		paint-order: stroke fill;
		text-shadow:
			0 0 0 #000,
			1px 1px 0 #000,
			-1px -1px 0 #000,
			2px 2px 0 rgba(0, 0, 0, 0.8);
	}
	.label {
		color: #ff9800;
		font-size: 17px;
	}
	.value {
		min-width: 0;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		color: #ffb300;
		font-size: 30px;
		line-height: 1;
		font-variant-numeric: tabular-nums;
	}
	.pulse .value {
		animation: stat-pulse 0.5s ease-in-out infinite alternate;
	}
	@keyframes stat-pulse {
		from {
			color: #ffb300;
		}
		to {
			color: #fff3c4;
			text-shadow:
				0 0 0 #000,
				1px 1px 0 #000,
				-1px -1px 0 #000,
				0 0 22px rgba(255, 213, 74, 0.9);
		}
	}
	:global(.nv-stage.portrait) .label {
		font-size: 13px;
	}
	:global(.nv-stage.portrait) .value {
		font-size: 24px;
	}
	@media (prefers-reduced-motion: reduce) {
		.pulse .value {
			animation: none;
		}
	}
</style>
