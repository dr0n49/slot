<script lang="ts">
	import { stateBet } from 'state-shared';

	import { formatAmount, formatBetLabel, formatBookWin } from '../../game/constants';
	import { stateGame } from '../../game/stateGame.svelte';
	import StatDisplay from './StatDisplay.svelte';

	const winDisplay = $derived(formatBookWin(stateGame.displayWin));
	const credits = $derived(formatAmount(stateBet.balanceAmount));

	// Progress bar: spins used during Free Spins, otherwise how far up the Blast Ladder the round is.
	const progressPct = $derived.by(() => {
		if (stateGame.fsActive && stateGame.fsTotal > 0) {
			return Math.round((stateGame.fsCurrent / stateGame.fsTotal) * 100);
		}
		const rungs = stateGame.ladderValues.length;
		if (rungs <= 1) return 0;
		return Math.round((Math.min(stateGame.ladderIndex, rungs - 1) / (rungs - 1)) * 100);
	});
	const progressLabel = $derived(stateGame.fsActive ? 'Free spins progress' : 'Blast ladder progress');
</script>

<div class="stats-row">
	<div class="win">
		<StatDisplay label="WIN" value={winDisplay} align="left" pulse={stateGame.winCounting} testid="win-value" />
	</div>
	<div class="bet">
		<span class="bet-label">BET {formatBetLabel(stateBet.betAmount)}</span>
		<div
			class="progress-track"
			role="progressbar"
			aria-label={progressLabel}
			aria-valuemin="0"
			aria-valuemax="100"
			aria-valuenow={progressPct}
		>
			<span class="star" aria-hidden="true">★</span>
			<div class="progress-fill" style="width: {progressPct}%"></div>
		</div>
	</div>
	<div class="credits">
		<StatDisplay label="CREDITS" value={credits} align="right" testid="balance-value" />
	</div>
</div>

<style>
	.stats-row {
		display: grid;
		grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
		align-items: end;
		gap: 10px;
		min-width: 0;
		flex-shrink: 0;
	}
	.bet {
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 3px;
		min-width: 96px;
	}
	.bet-label {
		color: #fff;
		font-family: var(--nv-font-hud);
		font-size: 12px;
		font-weight: 900;
		letter-spacing: 0.07em;
		text-shadow: 0 1px 0 #000;
	}
	.progress-track {
		position: relative;
		width: 110px;
		height: 8px;
		border: 1px solid rgba(255, 213, 74, 0.4);
		border-radius: 999px;
		background: rgba(0, 0, 0, 0.35);
		overflow: hidden;
	}
	.star {
		position: absolute;
		left: 2px;
		top: 50%;
		z-index: 2;
		color: #ffd54a;
		font-size: 8px;
		transform: translateY(-50%);
	}
	.progress-fill {
		height: 100%;
		border-radius: 999px;
		background: linear-gradient(90deg, #22c55e 0%, #4ade80 100%);
		transition: width 0.25s ease;
	}
	:global(.nv-stage.portrait) .stats-row {
		grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
		grid-template-areas:
			'win credits'
			'bet bet';
		row-gap: 4px;
	}
	:global(.nv-stage.portrait) .win {
		grid-area: win;
	}
	:global(.nv-stage.portrait) .credits {
		grid-area: credits;
	}
	:global(.nv-stage.portrait) .bet {
		grid-area: bet;
	}
	@media (prefers-reduced-motion: reduce) {
		.progress-fill {
			transition: none;
		}
	}
</style>
