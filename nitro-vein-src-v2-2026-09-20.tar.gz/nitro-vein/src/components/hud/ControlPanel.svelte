<script lang="ts">
	import { stateBet, stateBetDerived, stateModal } from 'state-shared';
	import { OnHotkey } from 'components-shared';

	import { BONUS_COST } from '../../game/config';
	import { getContext } from '../../game/context';
	import { formatBetLabel } from '../../game/constants';
	import { releaseContinue, requestSkip, tapBigWin } from '../../game/presentation';
	import { sfx } from '../../game/sfx';
	import { hideBanner, showBanner, stateGame } from '../../game/stateGame.svelte';
	import { uiState } from '../../game/uiState.svelte';
	import { ICONS } from './icons';
	import BetSelector from './BetSelector.svelte';

	const context = getContext();

	const xIdle = $derived(context.stateXstateDerived.isIdle());
	const isAuto = $derived(context.stateXstateDerived.isAutoBetting());
	const autoStopping = $derived(isAuto && stateBet.autoSpinsCounter === 0);
	const dialogOpen = $derived(stateModal.modal !== null || uiState.infoOpen || uiState.buyOpen);
	const roundRunning = $derived(stateGame.phase !== 'IDLE');

	const canSpin = $derived(stateGame.sceneReady && xIdle && stateGame.phase === 'IDLE' && !isAuto);
	const canChangeBet = $derived(stateGame.sceneReady && xIdle && stateGame.phase === 'IDLE' && !isAuto);
	const canToggleAuto = $derived(stateGame.sceneReady && (isAuto || (xIdle && stateGame.phase === 'IDLE')));
	const canBuy = $derived(canChangeBet);
	const bonusPrice = $derived(stateBet.betAmount * BONUS_COST);
	const canAffordBonus = $derived(bonusPrice <= stateBet.balanceAmount);
	const hasOverlay = $derived(
		Boolean(stateGame.bigWin || stateGame.featureIntro || stateGame.featureOutro || stateGame.awaitingContinue),
	);
	const canSkip = $derived(roundRunning && !hasOverlay && !stateGame.skip);

	const spinLabel = $derived(
		isAuto ? (autoStopping ? 'STOPPING' : 'STOP') : hasOverlay ? 'CONTINUE' : roundRunning ? 'SKIP' : 'SPIN',
	);
	const spinIcon = $derived(
		isAuto ? ICONS.stop : hasOverlay ? ICONS.ffwd : roundRunning ? ICONS.ffwd : ICONS.spin,
	);
	const autoCount = $derived(
		isAuto && Number.isFinite(stateBet.autoSpinsCounter) && stateBet.autoSpinsCounter > 0
			? String(stateBet.autoSpinsCounter)
			: '',
	);

	const tone = (name: 'ui_click' | 'ui_open' | 'ui_toggle') => {
		sfx.unlock();
		sfx.play(name);
		context.eventEmitter.broadcast({ type: 'soundPressGeneral' });
	};

	const toggleTurbo = () => {
		tone('ui_toggle');
		stateBetDerived.updateIsTurbo(!stateBet.isTurbo, { persistent: true });
	};
	const openOptions = () => {
		tone('ui_open');
		stateModal.modal = { name: 'settings' };
	};
	const openInfo = () => {
		tone('ui_open');
		uiState.infoOpen = true;
	};
	const openBuy = () => {
		if (!canBuy) return;
		tone('ui_open');
		uiState.buyOpen = true;
	};
	const toggleAuto = () => {
		if (!canToggleAuto) return;
		tone('ui_click');
		if (isAuto) {
			// finishes the running round, then the auto loop ends
			stateBet.autoSpinsCounter = 0;
			return;
		}
		stateModal.modal = { name: 'autoSpin' };
	};

	let insufficientTimer: ReturnType<typeof setTimeout> | undefined;
	const onSpin = () => {
		sfx.unlock();
		if (stateGame.bigWin) return tapBigWin();
		if (stateGame.awaitingContinue) return releaseContinue();
		if (isAuto) return toggleAuto();
		if (canSpin) {
			if (!stateBetDerived.isBetCostAvailable()) {
				sfx.play('error');
				const id = showBanner('INSUFFICIENT BALANCE', 'Lower your bet or add funds', 'warn');
				clearTimeout(insufficientTimer);
				insufficientTimer = setTimeout(() => hideBanner(id), 2200);
				return;
			}
			sfx.play('ui_click');
			context.eventEmitter.broadcast({ type: 'soundPressBet' });
			context.eventEmitter.broadcast({ type: 'bet' });
			return;
		}
		if (canSkip) requestSkip();
	};
</script>

<OnHotkey hotkey="Space" disabled={dialogOpen || !stateGame.sceneReady} onpress={onSpin} />

<div class="controls">
	<div class="cluster left">
		<button type="button" class="nv-btn opt" onclick={openOptions} aria-label="Settings">Options</button>
		<button type="button" class="nv-btn info" onclick={openInfo} aria-label="Game info and paytable">Info</button>
		<button
			type="button"
			class="nv-btn turbo"
			class:active={stateBet.isTurbo}
			aria-pressed={stateBet.isTurbo}
			onclick={toggleTurbo}
			data-testid="turbo"
		>
			Turbo <span class="chevrons" aria-hidden="true">›››</span>
		</button>
		<div class="betwrap"><BetSelector disabled={!canChangeBet} /></div>
	</div>

	<button
		type="button"
		class="spin"
		class:ready={canSpin}
		class:auto={isAuto}
		class:busy={roundRunning && !isAuto}
		disabled={!canSpin && !canSkip && !isAuto && !hasOverlay}
		onclick={onSpin}
		aria-label={spinLabel}
		data-testid="spin"
	>
		<span class="ring"></span>
		<svg viewBox="0 0 24 24" aria-hidden="true"><path d={spinIcon} /></svg>
		<span class="cap">{autoCount || spinLabel}</span>
	</button>

	<div class="cluster right">
		<button
			type="button"
			class="nv-btn auto-btn"
			class:active={isAuto}
			class:stopping={isAuto}
			aria-pressed={isAuto}
			disabled={!canToggleAuto}
			onclick={toggleAuto}
			data-testid="auto"
		>
			{isAuto ? (autoStopping ? 'Stopping' : 'Stop') : 'Auto'}
		</button>
		<button
			type="button"
			class="nv-btn buy"
			disabled={!canBuy}
			onclick={openBuy}
			aria-label={`Buy bonus for ${formatBetLabel(bonusPrice)}`}
			data-testid="buy"
		>
			<span class="name">Buy Bonus</span>
			<span class="price" class:poor={!canAffordBonus}>{formatBetLabel(bonusPrice)}</span>
		</button>
	</div>
</div>

<style>
	.controls {
		display: grid;
		grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
		align-items: center;
		gap: 14px;
		flex-shrink: 0;
	}
	.cluster {
		display: flex;
		align-items: center;
		gap: 8px;
	}
	.cluster.left {
		justify-content: flex-end;
	}
	.cluster.right {
		justify-content: flex-start;
	}
	.cluster .nv-btn {
		min-width: 74px;
		min-height: 38px;
		font-size: 11px;
	}
	.betwrap {
		margin-left: 6px;
	}
	.nv-btn.auto-btn.stopping {
		border-color: #7f1d1d;
		background: linear-gradient(180deg, #f87171 0%, #dc2626 48%, #b91c1c 100%);
		color: #fff;
	}
	/* bonus-buy button: blue plate, gold rim, star badge (as Slot_1's JoB+/Flush+) */
	.nv-btn.buy {
		flex-direction: column;
		gap: 1px;
		min-width: 108px;
		min-height: 44px;
		padding: 5px 12px;
		line-height: 1.1;
		border: 2px solid transparent;
		background:
			linear-gradient(180deg, #0d2a8a 0%, #071858 100%) padding-box,
			linear-gradient(135deg, #fde68a 0%, #f59e0b 45%, #b45309 100%) border-box;
		box-shadow:
			inset 0 1px 0 rgba(255, 255, 255, 0.25),
			0 0 12px rgba(251, 191, 36, 0.35),
			0 2px 6px rgba(0, 0, 0, 0.45);
		color: #fff8dc;
	}
	.nv-btn.buy::before {
		content: '★';
		position: absolute;
		top: -7px;
		right: -5px;
		width: 18px;
		height: 18px;
		border-radius: 999px;
		background: linear-gradient(180deg, #fde68a, #f59e0b);
		color: #7a1a00;
		font-size: 10px;
		line-height: 18px;
		text-align: center;
		box-shadow: 0 1px 3px rgba(0, 0, 0, 0.4);
	}
	.nv-btn.buy .name {
		font-size: 11px;
		letter-spacing: 0.04em;
	}
	.price {
		font-size: 12px;
		font-weight: 900;
		letter-spacing: 0.02em;
		color: #ffd54a;
	}
	.price.poor {
		color: #ff8a8a;
	}

	.spin {
		position: relative;
		display: inline-flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		width: 76px;
		height: 76px;
		margin: 0;
		padding: 0;
		border: 4px solid #ffd54a;
		border-radius: 50%;
		background: radial-gradient(circle at 50% 30%, #ffb14a 0%, #ff6a1a 45%, #b02a08 100%);
		box-shadow:
			inset 0 3px 0 rgba(255, 255, 255, 0.45),
			inset 0 -6px 0 rgba(0, 0, 0, 0.3),
			0 6px 14px rgba(0, 0, 0, 0.6),
			0 0 22px rgba(255, 106, 26, 0.55);
		color: #fff;
		cursor: pointer;
		transition: transform 0.08s ease, filter 0.12s ease;
	}
	.spin svg {
		width: 30px;
		height: 30px;
		fill: currentColor;
		filter: drop-shadow(0 2px 0 rgba(0, 0, 0, 0.45));
	}
	.spin.ready svg {
		animation: spin-idle 3.6s linear infinite;
	}
	.spin.busy svg {
		width: 30px;
		height: 30px;
	}
	.cap {
		margin-top: -2px;
		font-family: var(--nv-font-hud);
		font-weight: 900;
		font-size: 13px;
		letter-spacing: 0.08em;
		text-shadow: 0 2px 0 rgba(0, 0, 0, 0.55);
	}
	.ring {
		position: absolute;
		inset: -12px;
		border-radius: 50%;
		border: 2px solid rgba(255, 213, 74, 0);
		pointer-events: none;
	}
	.spin.ready .ring {
		animation: spin-ring 1.8s ease-out infinite;
	}
	.spin:hover:not(:disabled) {
		filter: brightness(1.1);
	}
	.spin:active:not(:disabled) {
		transform: scale(0.95);
	}
	.spin:disabled {
		filter: grayscale(0.6) brightness(0.7);
		cursor: not-allowed;
	}
	.spin:focus-visible {
		outline: 4px solid var(--nv-cyan);
		outline-offset: 4px;
	}
	.spin.auto {
		background: radial-gradient(circle at 50% 30%, #ff8a8a 0%, #d81f1f 55%, #7a0a0a 100%);
	}
	@keyframes spin-idle {
		to {
			transform: rotate(360deg);
		}
	}
	@keyframes spin-ring {
		0% {
			transform: scale(0.94);
			border-color: rgba(255, 213, 74, 0.7);
		}
		100% {
			transform: scale(1.18);
			border-color: rgba(255, 213, 74, 0);
		}
	}

	/* portrait: two rows - [Options Info Turbo Auto] / [bet · SPIN · Buy Bonus] */
	:global(.nv-stage.portrait) .controls {
		grid-template-columns: repeat(4, minmax(0, 1fr));
		grid-template-areas:
			'opt info turbo auto'
			'bet bet spin buy';
		gap: 6px 8px;
		justify-items: center;
	}
	:global(.nv-stage.portrait) .cluster {
		display: contents;
	}
	:global(.nv-stage.portrait) .cluster .nv-btn {
		min-width: 0;
		width: 100%;
		max-width: 110px;
		padding-inline: 6px;
		font-size: 10px;
	}
	:global(.nv-stage.portrait) .opt {
		grid-area: opt;
	}
	:global(.nv-stage.portrait) .info {
		grid-area: info;
	}
	:global(.nv-stage.portrait) .turbo {
		grid-area: turbo;
	}
	:global(.nv-stage.portrait) .auto-btn {
		grid-area: auto;
	}
	:global(.nv-stage.portrait) .betwrap {
		grid-area: bet;
		margin: 0;
		justify-self: start;
	}
	:global(.nv-stage.portrait) .spin {
		grid-area: spin;
		width: 92px;
		height: 92px;
		margin: -4px 0 0;
	}
	:global(.nv-stage.portrait) .nv-btn.buy {
		grid-area: buy;
		max-width: 120px;
		min-width: 0;
	}
	@media (prefers-reduced-motion: reduce) {
		.spin.ready svg,
		.spin.ready .ring {
			animation: none;
		}
	}
</style>
