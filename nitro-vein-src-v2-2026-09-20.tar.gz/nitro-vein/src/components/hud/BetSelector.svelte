<script lang="ts">
	import { stateBet, stateBetDerived } from 'state-shared';

	import { sfx } from '../../game/sfx';
	import { getContext } from '../../game/context';
	import { betAmountIndex, formatBetLabel, resolvedBetAmountOptions } from '../../game/constants';

	type Props = { disabled?: boolean };
	const { disabled = false }: Props = $props();

	const context = getContext();
	let open = $state(false);

	const betOptions = $derived(resolvedBetAmountOptions());
	const currentIdx = $derived(betAmountIndex(stateBet.betAmount, betOptions));
	const atMin = $derived(currentIdx <= 0);
	const atMax = $derived(currentIdx >= betOptions.length - 1);

	const setBet = (amount: number) => {
		sfx.unlock();
		sfx.play('bet_change');
		context.eventEmitter.broadcast({ type: 'soundPressGeneral' });
		stateBetDerived.setBetAmount(amount);
		open = false;
	};
	const stepUp = () => {
		if (disabled || atMax) return;
		setBet(betOptions[currentIdx + 1]);
	};
	const stepDown = () => {
		if (disabled || atMin) return;
		setBet(betOptions[currentIdx - 1]);
	};
	const toggleOpen = () => {
		if (disabled) return;
		sfx.click();
		open = !open;
	};
	const onWindowClick = (event: MouseEvent) => {
		if (!(event.target as HTMLElement).closest('.bet-selector')) open = false;
	};
</script>

<svelte:window onclick={onWindowClick} />

<div class="bet-selector">
	<button type="button" class="step" aria-label="Lower bet" disabled={disabled || atMin} onclick={stepDown}>
		▼
	</button>

	<div class="picker">
		<button
			type="button"
			class="value"
			data-testid="bet-value"
			{disabled}
			aria-expanded={open}
			aria-haspopup="listbox"
			onclick={toggleOpen}
		>
			{formatBetLabel(stateBet.betAmount)}
		</button>

		{#if open}
			<ul class="menu" role="listbox" aria-label="Bet amount">
				{#each betOptions as amount (amount)}
					<li role="option" aria-selected={amount === stateBet.betAmount}>
						<button type="button" class:selected={amount === stateBet.betAmount} onclick={() => setBet(amount)}>
							{formatBetLabel(amount)}
						</button>
					</li>
				{/each}
			</ul>
		{/if}
	</div>

	<button type="button" class="step" aria-label="Raise bet" disabled={disabled || atMax} onclick={stepUp}>
		▲
	</button>
</div>

<style>
	.bet-selector {
		display: inline-flex;
		align-items: center;
		gap: 3px;
		position: relative;
	}
	.step {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 28px;
		min-height: 36px;
		padding: 0;
		border: 2px solid #8b6914;
		border-radius: 5px;
		background: linear-gradient(180deg, #ffd700 0%, #daa520 48%, #b8860b 100%);
		box-shadow:
			inset 0 1px 0 rgba(255, 255, 255, 0.4),
			0 1px 3px rgba(0, 0, 0, 0.35);
		color: #111;
		font-size: 10px;
		font-weight: 900;
		line-height: 1;
		cursor: pointer;
		transition: filter 0.12s ease, transform 0.08s ease;
	}
	.step:hover:not(:disabled) {
		filter: brightness(1.08);
	}
	.step:active:not(:disabled) {
		transform: translateY(1px);
	}
	.step:disabled {
		opacity: 0.38;
		cursor: not-allowed;
	}
	.step:focus-visible,
	.value:focus-visible,
	.menu button:focus-visible {
		outline: 3px solid var(--nv-cyan);
		outline-offset: 2px;
	}
	.picker {
		position: relative;
	}
	.value {
		min-width: 68px;
		min-height: 36px;
		padding: 3px 14px;
		border: 2px solid #8b6914;
		border-radius: 999px;
		background: linear-gradient(180deg, #ffd700 0%, #daa520 48%, #b8860b 100%);
		box-shadow:
			inset 0 1px 0 rgba(255, 255, 255, 0.45),
			inset 0 -2px 0 rgba(0, 0, 0, 0.22),
			0 2px 4px rgba(0, 0, 0, 0.4);
		color: #7a1a00;
		font-family: var(--nv-font-hud);
		font-size: 14px;
		font-weight: 900;
		letter-spacing: 0.03em;
		cursor: pointer;
	}
	.value:hover:not(:disabled) {
		filter: brightness(1.07);
	}
	.value:disabled {
		cursor: not-allowed;
		opacity: 0.42;
	}
	.menu {
		position: absolute;
		bottom: calc(100% + 6px);
		left: 50%;
		z-index: 60;
		transform: translateX(-50%);
		margin: 0;
		padding: 4px;
		list-style: none;
		width: max-content;
		min-width: 80px;
		max-height: 240px;
		overflow-y: auto;
		border: 2px solid #8b6914;
		border-radius: 8px;
		background: linear-gradient(180deg, #001a5c 0%, #000820 100%);
		box-shadow: 0 6px 20px rgba(0, 0, 0, 0.55);
	}
	.menu button {
		display: block;
		width: 100%;
		padding: 6px 12px;
		border: none;
		border-radius: 4px;
		background: transparent;
		color: #ffd54a;
		font-family: var(--nv-font-hud);
		font-size: 13px;
		font-weight: 900;
		text-align: center;
		cursor: pointer;
	}
	.menu button:hover,
	.menu button.selected {
		background: rgba(255, 213, 74, 0.18);
		color: #fff;
	}
</style>
