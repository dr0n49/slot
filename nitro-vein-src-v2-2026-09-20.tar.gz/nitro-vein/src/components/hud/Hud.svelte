<script lang="ts">
	import ControlPanel from './ControlPanel.svelte';
	import StatsBar from './StatsBar.svelte';

	type Props = { height: number };
	const { height }: Props = $props();
</script>

<div class="hud" style="height: {height}px">
	<StatsBar />
	<ControlPanel />
</div>

<style>
	.hud {
		position: absolute;
		left: 0;
		right: 0;
		bottom: 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		gap: 6px;
		padding: 6px 28px 8px;
		box-sizing: border-box;
		border-top: 2px solid rgba(255, 213, 74, 0.5);
		background: linear-gradient(180deg, rgba(0, 8, 40, 0.94) 0%, rgba(0, 18, 64, 0.99) 100%);
		box-shadow: 0 -8px 24px rgba(0, 0, 0, 0.55);
		pointer-events: auto;
		z-index: 20;
	}
	:global(.nv-stage.portrait) .hud {
		padding: 8px 14px 12px;
		gap: 6px;
		justify-content: flex-start;
	}
</style>
