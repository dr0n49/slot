<script lang="ts">
	import { stateBet, stateBetDerived, stateModal } from 'state-shared';

	import { getContext } from '../../game/context';
	import { formatBetLabel, LIVE_BONUS_COST } from '../../game/constants';
	import {
		isLiveRoundStartable,
		runLiveBonusRound,
		submitLiveDoubleUpChoice,
		submitLiveHold,
	} from '../../game/liveWallet';
	import { stateGame } from '../../game/stateGame.svelte';
	import BetSelector from './BetSelector.svelte';

	const context = getContext();

	const gameOver = $derived(
		stateGame.roundState === 'settled' ||
			stateGame.roundState === 'error' ||
			stateGame.roundState === 'timeout',
	);

	const canDeal = $derived(
		stateGame.liveWalletStatus !== 'offline' &&
			stateGame.liveWalletStatus !== 'starting' &&
			(stateGame.awaitingPlayerHold || isLiveRoundStartable()),
	);

	const canBetChange = $derived(
		!stateGame.liveBetRunning &&
			!stateGame.awaitingPlayerHold &&
			!stateGame.awaitingDoubleUpChoice &&
			isLiveRoundStartable(),
	);

	const canBuyBonus = $derived(canBetChange && stateGame.liveWalletEnabled);

	const inDoubleUpChoice = $derived(stateGame.awaitingDoubleUpChoice);

	const dealLabel = $derived(stateGame.awaitingPlayerHold ? 'DRAW' : 'DEAL');

	const jobCost = $derived(stateBet.betAmount * LIVE_BONUS_COST.job);
	const flushCost = $derived(stateBet.betAmount * LIVE_BONUS_COST.flush);

	let duPending = $state(false);

	const toggleSpeed = () => {
		context.eventEmitter.broadcast({ type: 'soundPressGeneral' });
		stateBetDerived.updateIsTurbo(!stateBet.isTurbo, { persistent: false });
	};

	const openOptions = () => {
		context.eventEmitter.broadcast({ type: 'soundPressGeneral' });
		stateModal.modal = { name: 'settings' };
	};

	const onDeal = () => {
		context.eventEmitter.broadcast({ type: 'soundPressBet' });
		if (stateGame.awaitingPlayerHold) {
			void submitLiveHold();
			return;
		}
		context.eventEmitter.broadcast({ type: 'bet' });
	};

	const onDoubleUpChoice = async (choice: 'collect' | 'red' | 'black') => {
		if (duPending || !inDoubleUpChoice) return;
		duPending = true;
		try {
			await submitLiveDoubleUpChoice(choice);
		} finally {
			duPending = false;
		}
	};

	const buyBonus = async (kind: 'job' | 'flush') => {
		if (!canBuyBonus) return;
		try {
			await runLiveBonusRound(kind);
		} catch (error) {
			const message = error instanceof Error ? error.message : String(error);
			stateModal.modal = { name: 'error', error: message };
		}
	};
</script>

<div class="control-panel">
	{#if inDoubleUpChoice}
		<div class="buttons-row du-row">
			<button
				type="button"
				class="casino-btn du-collect"
				disabled={duPending}
				onclick={() => void onDoubleUpChoice('collect')}
			>
				Collect
			</button>
			<button
				type="button"
				class="casino-btn du-red"
				disabled={duPending}
				onclick={() => void onDoubleUpChoice('red')}
			>
				Red
			</button>
			<button
				type="button"
				class="casino-btn du-black"
				disabled={duPending}
				onclick={() => void onDoubleUpChoice('black')}
			>
				Black
			</button>
		</div>
	{:else}
		<div class="buttons-row">
			<button type="button" class="casino-btn" onclick={openOptions}>Options</button>
			<button
				type="button"
				class="casino-btn speed"
				class:active={stateBet.isTurbo}
				onclick={toggleSpeed}
			>
				Speed <span class="chevrons">›››</span>
			</button>
			<BetSelector disabled={!canBetChange} />
			<button type="button" class="casino-btn deal" disabled={!canDeal} onclick={onDeal}>
				{dealLabel}
			</button>
		</div>

		{#if stateGame.liveWalletEnabled}
			<div class="bonus-row">
				<button
					type="button"
					class="casino-btn bonus"
					disabled={!canBuyBonus}
					onclick={() => buyBonus('job')}
				>
					<span class="bonus-name">MIN WIN: JoB+</span>
					<span class="bonus-cost">Cost: {formatBetLabel(jobCost)}</span>
				</button>
				<button
					type="button"
					class="casino-btn bonus"
					disabled={!canBuyBonus}
					onclick={() => buyBonus('flush')}
				>
					<span class="bonus-name">MIN WIN: Flush+</span>
					<span class="bonus-cost">Cost: {formatBetLabel(flushCost)}</span>
				</button>
			</div>
		{/if}
	{/if}

	<div class="footer-row">
		<span class="footer-left">JACKS OR BETTER</span>
		{#if gameOver}
			<span class="footer-right">GAME OVER</span>
		{/if}
	</div>
</div>

<style>
	.control-panel {
		display: flex;
		flex-direction: column;
		gap: 8px;
		padding: 8px 10px 6px;
		margin-top: auto;
		flex-shrink: 0;
		border-top: 2px solid rgba(255, 213, 74, 0.25);
		background: linear-gradient(180deg, rgba(0, 8, 40, 0.9) 0%, rgba(0, 18, 64, 0.98) 100%);
	}
	.buttons-row,
	.bonus-row {
		display: flex;
		flex-wrap: wrap;
		justify-content: center;
		align-items: center;
		gap: 4px;
		flex-shrink: 0;
	}
	.buttons-row {
		width: 100%;
	}
	.buttons-row :global(.bet-selector) {
		flex: 1 1 auto;
		justify-content: center;
	}
	.buttons-row .casino-btn.deal {
		flex: 1 1 auto;
		max-width: 88px;
	}
	.du-row {
		padding-top: 2px;
	}
	.casino-btn.speed .chevrons {
		color: #dc2626;
		letter-spacing: -2px;
		margin-left: 1px;
		font-size: 9px;
	}
	.casino-btn.active {
		box-shadow:
			inset 0 1px 0 rgba(255, 255, 255, 0.5),
			0 0 12px rgba(255, 213, 74, 0.65);
	}
	.casino-btn.bonus {
		flex: 0 1 calc(50% - 4px);
		max-width: 118px;
		flex-direction: column;
		align-items: center;
		gap: 1px;
		min-height: 34px;
		padding: 4px 6px;
		line-height: 1.15;
	}
	.bonus-name {
		font-size: 8px;
	}
	.bonus-cost {
		font-size: 8px;
		font-weight: 700;
		color: inherit;
		opacity: 0.85;
		letter-spacing: 0.02em;
	}
	.footer-row {
		display: flex;
		justify-content: space-between;
		align-items: center;
		min-height: 14px;
		flex-shrink: 0;
	}
	.footer-left,
	.footer-right {
		font-family: 'Arial Black', Impact, sans-serif;
		font-size: 9px;
		font-weight: 900;
		letter-spacing: 0.08em;
		text-shadow: 0 1px 0 #000;
	}
	.footer-left {
		color: rgba(255, 255, 255, 0.55);
	}
	.footer-right {
		color: #fff;
		animation: blink 1.2s step-end infinite;
	}
	@keyframes blink {
		50% {
			opacity: 0.35;
		}
	}
</style>
