<script lang="ts">
	import { HAND_SIZE, formatMultiplier } from '../../game/constants';
	import { stateGame } from '../../game/stateGame.svelte';
	import Card from './Card.svelte';
	import ControlPanel from './ControlPanel.svelte';
	import HeldLabel from './HeldLabel.svelte';
	import PaytableTable from './PaytableTable.svelte';
	import StatsBar from './StatsBar.svelte';

	import './casinoTheme.css';

	const combinationText = $derived.by(() => {
		if (stateGame.liveWalletStatus === 'starting') return '';
		if (stateGame.liveWalletStatus === 'offline') return '';
		if (stateGame.awaitingPlayerHold) return '';
		if (stateGame.doubleUpRevealed && stateGame.doubleUpCorrect === false) return '';
		if (stateGame.handCategory && stateGame.handAmount > 0) {
			return stateGame.handCategory.toUpperCase();
		}
		return '';
	});

	const inDoubleUp = $derived(
		stateGame.awaitingDoubleUpChoice ||
			stateGame.doubleUpRevealing ||
			stateGame.doubleUpRevealed,
	);

	const duShowFace = $derived(stateGame.doubleUpRevealed && Boolean(stateGame.doubleUpCard));
	const duFlipping = $derived(stateGame.doubleUpRevealing);

	const showCardBacks = $derived(stateGame.cards.length === 0 && !inDoubleUp);
	const interactive = $derived(
		stateGame.awaitingPlayerHold &&
			(stateGame.liveHold || stateGame.liveWalletEnabled),
	);
	const winningHand = $derived(
		Boolean(stateGame.handCategory && stateGame.handAmount > 0 && !stateGame.awaitingPlayerHold),
	);

	const toggleHold = (index: number) => {
		if (!interactive) return;
		const nextHeld = !stateGame.cards[index].held;
		stateGame.cards[index] = { ...stateGame.cards[index], held: nextHeld };
		stateGame.holdMask = stateGame.cards.reduce(
			(mask, card, i) => (card.held ? mask | (1 << i) : mask),
			0,
		);
		stateGame.showHolds = true;
	};
</script>

<div class="casino-machine" class:double-up-active={inDoubleUp}>
	<PaytableTable />

	{#if !inDoubleUp}
		<div class="combination-banner" class:win={winningHand}>
			{#if combinationText}
				<span>{combinationText}</span>
			{/if}
		</div>
	{/if}

	<div class="card-stage" class:double-up-stage={inDoubleUp}>
		{#if inDoubleUp}
			<div class="double-up-stack" aria-label="Double-up">
				<p class="du-banner">
					Double-up {stateGame.doubleUpStep}/{stateGame.doubleUpMaxSteps} — at risk
					{formatMultiplier(stateGame.doubleUpAmountAtRisk)}
				</p>

				<div class="card-slot du-card-slot">
					<div class="card-flip" class:flipping={duFlipping} class:revealed={duShowFace}>
						<div class="card-flip-inner">
							<div class="card-flip-face card-flip-back">
								<Card showBack={true} />
							</div>
							<div class="card-flip-face card-flip-front">
								{#if stateGame.doubleUpCard}
									<Card code={stateGame.doubleUpCard} />
								{/if}
							</div>
						</div>
					</div>
				</div>

				<div class="du-result-slot">
					<p
						class="du-result"
						class:visible={stateGame.doubleUpRevealed}
						class:win={stateGame.doubleUpCorrect}
						class:lose={stateGame.doubleUpRevealed && !stateGame.doubleUpCorrect}
						aria-live="polite"
					>
						{#if stateGame.doubleUpRevealed}
							{#if stateGame.doubleUpCorrect}
								SURVIVED — win doubles to {formatMultiplier(stateGame.doubleUpAmountAfter)}
							{:else}
								MISS — win goes to 0
							{/if}
						{/if}
					</p>
				</div>
			</div>
		{:else}
			<div class="card-row" class:win={winningHand}>
				{#if showCardBacks}
					{#each Array(HAND_SIZE) as _, index (index)}
						<div class="card-slot">
							<HeldLabel visible={false} />
							<Card showBack={true} />
						</div>
					{/each}
				{:else}
					{#each stateGame.cards as card, index (index)}
						<div class="card-slot">
							<HeldLabel visible={stateGame.showHolds && card.held} />
							<Card
								code={card.code}
								held={stateGame.showHolds && card.held}
								drawing={card.drawing}
								winning={winningHand}
								interactive={interactive}
								onclick={() => toggleHold(index)}
							/>
						</div>
					{/each}
				{/if}
			</div>
		{/if}
	</div>

	<StatsBar />

	<ControlPanel />
</div>

<style>
	.casino-machine {
		display: flex;
		flex-direction: column;
		width: 100%;
		min-height: 100%;
		height: 100%;
		background: linear-gradient(180deg, #0a1f6e 0%, #001240 100%);
		overflow-x: hidden;
		overflow-y: auto;
		box-sizing: border-box;
	}
	.casino-machine.double-up-active {
		overflow-y: hidden;
	}

	.combination-banner {
		display: flex;
		align-items: center;
		justify-content: center;
		flex-shrink: 0;
		min-height: 28px;
		padding: 2px 12px 0;
		text-align: center;
	}
	.combination-banner span {
		color: #fff;
		font-family: 'Arial Black', Impact, sans-serif;
		font-size: clamp(16px, 3.2vw, 24px);
		font-weight: 900;
		letter-spacing: 0.07em;
		text-shadow: 0 2px 0 #000;
	}
	.combination-banner.win span {
		animation: combo-pulse 1.4s ease-in-out infinite;
	}

	.card-stage {
		flex-shrink: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		padding: 4px 10px 28px;
		margin-bottom: 4px;
		min-height: min(160px, 38vw);
		width: 100%;
		box-sizing: border-box;
	}
	.card-stage.double-up-stage {
		align-items: center;
		justify-content: center;
		min-height: 0;
		padding: 2px 10px 10px;
		margin-bottom: 0;
	}
	.card-row {
		display: grid;
		grid-template-columns: repeat(5, minmax(0, 1fr));
		gap: clamp(4px, 1.2vw, 10px);
		width: min(100%, 620px);
	}
	.card-row.win :global(.card) {
		animation: card-win-glow 1.6s ease-in-out infinite;
	}
	.card-slot {
		display: flex;
		flex-direction: column;
		align-items: center;
		min-width: 0;
	}
	.card-slot :global(.card) {
		max-width: min(17vw, 96px);
	}

	.du-card-slot {
		width: min(17vw, 96px);
		flex-shrink: 0;
	}

	.double-up-stack {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		width: 100%;
		max-width: min(100%, 620px);
		margin-inline: auto;
		gap: clamp(10px, 2vw, 14px);
	}
	.du-banner {
		margin: 0;
		width: 100%;
		color: #ffd54a;
		font-family: 'Arial Black', Impact, sans-serif;
		font-size: clamp(11px, 2.2vw, 16px);
		font-weight: 900;
		letter-spacing: 0.06em;
		line-height: 1.15;
		text-align: center;
		text-shadow: 0 1px 0 #000;
	}

	.card-flip {
		width: 100%;
		perspective: 900px;
	}
	.card-flip-inner {
		position: relative;
		width: 100%;
		aspect-ratio: 5 / 7;
		transform-style: preserve-3d;
		transition: transform 0.42s ease-in-out;
	}
	.card-flip.flipping .card-flip-inner,
	.card-flip.revealed .card-flip-inner {
		transform: rotateY(180deg);
	}
	.card-flip-face {
		position: absolute;
		inset: 0;
		backface-visibility: hidden;
		display: flex;
	}
	.card-flip-face :global(.card) {
		width: 100%;
		height: 100%;
		max-width: 100%;
		max-height: 100%;
		aspect-ratio: unset;
	}

	.card-flip-front {
		transform: rotateY(180deg);
	}

	.du-result-slot {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 100%;
		max-width: min(100%, 620px);
		min-height: 1.15em;
		flex-shrink: 0;
	}
	.du-result {
		margin: 0;
		width: 100%;
		font-family: 'Arial Black', Impact, sans-serif;
		font-size: clamp(10px, 1.8vw, 12px);
		font-weight: 900;
		letter-spacing: 0.04em;
		line-height: 1.15;
		text-align: center;
		text-shadow: 0 1px 0 #000;
		opacity: 0;
		visibility: hidden;
		transition: opacity 0.2s ease;
	}
	.du-result.visible {
		opacity: 1;
		visibility: visible;
	}
	.du-result.win {
		color: #ffd54a;
	}
	.du-result.lose {
		color: #fca5a5;
	}

	@keyframes combo-pulse {
		0%,
		100% {
			text-shadow: 0 2px 0 #000;
		}
		50% {
			text-shadow:
				0 2px 0 #000,
				0 0 18px rgba(255, 213, 74, 0.55);
		}
	}
	@keyframes card-win-glow {
		0%,
		100% {
			box-shadow:
				0 8px 16px rgba(0, 0, 0, 0.45),
				0 0 0 0 rgba(255, 213, 74, 0);
		}
		50% {
			box-shadow:
				0 10px 20px rgba(0, 0, 0, 0.5),
				0 0 14px rgba(255, 213, 74, 0.5);
		}
	}

	:global(.game-root.casino-mode) {
		display: flex;
		flex-direction: column;
		min-height: 100vh;
		height: 100%;
	}
	:global(.game-root.casino-mode) .casino-machine {
		flex: 1 1 auto;
		min-height: 0;
		position: relative;
		z-index: 30;
	}
</style>
