import { recordBookEvent, type BookEventHandlerMap } from 'utils-book';
import { stateBet } from 'state-shared';
import { waitForTimeout, waitForResolve } from 'utils-shared/wait';

import {
	revealDealHand,
	revealDrawnCards,
	setDealHandInstant,
	setDrawHandInstant,
} from './cardReveal';
import { eventEmitter } from './eventEmitter';
import { isCasinoShell } from './liveDevHud';
import { stateGame } from './stateGame.svelte';
import { isHeld } from './constants';
import type { BookEvent, BookEventOfType, BookEventContext } from './typesBookEvent';

const useCardReveal = () => stateGame.liveHold || stateGame.liveWalletEnabled;
const skipPlaybackGate = () => stateGame.liveHold || stateGame.liveWalletEnabled;

export const bookEventHandlerMap: BookEventHandlerMap<BookEvent, BookEventContext> = {
	deal: async (bookEvent: BookEventOfType<'deal'>) => {
		stateGame.roundState = 'initialDeal';
		stateGame.handCategory = '';
		stateGame.handAmount = 0;
		stateGame.showHolds = false;
		stateGame.awaitingDraw = false;
		stateGame.holdMask = 0;
		stateGame.doubleUpSkipped = false;
		stateGame.doubleUpActive = false;
		if (useCardReveal()) {
			if (stateBet.isTurbo) {
				setDealHandInstant(bookEvent.cards);
			} else {
				await revealDealHand(bookEvent.cards);
			}
		} else {
			stateGame.cards = bookEvent.cards.map((c) => ({
				code: c.card,
				held: false,
				drawing: false,
			}));
		}
		if (
			(stateGame.liveHold || isCasinoShell()) &&
			stateGame.roundState === 'initialDeal' &&
			!stateGame.liveBonusBuy
		) {
			stateGame.roundState = 'holdSelection';
			stateGame.showHolds = true;
			stateGame.awaitingPlayerHold = true;
		}
		await eventEmitter.broadcastAsync({ type: 'holdSelectionDeal' });
		recordBookEvent({ bookEvent });
	},
	hold: async (bookEvent: BookEventOfType<'hold'>) => {
		stateGame.roundState = 'holdSelection';
		stateGame.holdMask = bookEvent.holdMask;
		stateGame.showHolds = true;
		stateGame.cards = stateGame.cards.map((card, index) => ({
			...card,
			held: isHeld(bookEvent.holdMask, index),
		}));
		if (skipPlaybackGate()) {
			recordBookEvent({ bookEvent });
			return;
		}
		stateGame.awaitingDraw = true;
		await waitForResolve((resolve) => {
			stateGame.continueDraw = resolve;
		});
		stateGame.continueDraw = null;
		stateGame.awaitingDraw = false;
		recordBookEvent({ bookEvent });
	},
	draw: async (bookEvent: BookEventOfType<'draw'>) => {
		stateGame.roundState = 'draw';
		if (stateBet.isTurbo) {
			setDrawHandInstant(bookEvent.finalHand, stateGame.holdMask);
		} else {
			await revealDrawnCards(bookEvent.drawn, bookEvent.finalHand, stateGame.holdMask);
		}
		await eventEmitter.broadcastAsync({ type: 'holdSelectionDrawDone' });
		recordBookEvent({ bookEvent });
	},
	handResult: async (bookEvent: BookEventOfType<'handResult'>) => {
		stateGame.roundState = 'handResult';
		stateGame.handCategory = bookEvent.category;
		stateGame.handAmount = bookEvent.amount;
		stateGame.doubleUpSkipped = bookEvent.amount <= 0;
		stateGame.doubleUpActive = false;
		await eventEmitter.broadcastAsync({ type: 'holdSelectionHandResult' });
		if (bookEvent.amount > 0 && !stateBet.isTurbo) await waitForTimeout(700);
		recordBookEvent({ bookEvent });
	},
	doubleUp: async (bookEvent: BookEventOfType<'doubleUp'>) => {
		stateGame.roundState = 'doubleUpRound';
		const atRisk =
			stateGame.doubleUpAmountAfter > 0 ? stateGame.doubleUpAmountAfter : stateGame.handAmount;
		stateGame.doubleUpSkipped = false;
		stateGame.doubleUpActive = true;
		stateGame.doubleUpStep = bookEvent.step;
		stateGame.doubleUpCard = bookEvent.card;
		stateGame.doubleUpColour = bookEvent.colour;
		stateGame.doubleUpCorrect = bookEvent.correct;
		stateGame.doubleUpAmountAtRisk = atRisk;
		stateGame.doubleUpAmountAfter = bookEvent.amountAfter;
		stateGame.doubleUpRevealing = false;
		stateGame.doubleUpRevealed = false;

		if (skipPlaybackGate()) {
			stateGame.awaitingDoubleUpChoice = false;
			stateGame.doubleUpRevealing = true;
			await eventEmitter.broadcastAsync({ type: 'doubleUpRevealStart' });
			await waitForTimeout(220);
			stateGame.doubleUpRevealing = false;
			stateGame.doubleUpRevealed = true;
			if (bookEvent.correct) {
				stateGame.doubleUpAmountAtRisk = bookEvent.amountAfter;
			} else {
				stateGame.doubleUpAmountAtRisk = 0;
			}
			await eventEmitter.broadcastAsync({ type: 'doubleUpRevealDone' });
			await waitForTimeout(500);
			recordBookEvent({ bookEvent });
			return;
		}

		stateGame.awaitingDoubleUpReveal = true;
		await waitForResolve((resolve) => {
			stateGame.continueDoubleUpReveal = resolve;
		});
		stateGame.continueDoubleUpReveal = null;
		stateGame.awaitingDoubleUpReveal = false;
		stateGame.doubleUpRevealing = true;
		await eventEmitter.broadcastAsync({ type: 'doubleUpRevealStart' });
		await waitForTimeout(220);
		stateGame.doubleUpRevealing = false;
		stateGame.doubleUpRevealed = true;
		if (bookEvent.correct) {
			stateGame.doubleUpAmountAtRisk = bookEvent.amountAfter;
		} else {
			stateGame.doubleUpAmountAtRisk = 0;
		}
		await eventEmitter.broadcastAsync({ type: 'doubleUpRevealDone' });
		await waitForTimeout(500);
		recordBookEvent({ bookEvent });
	},
	setTotalWin: async (bookEvent: BookEventOfType<'setTotalWin'>) => {
		stateBet.winBookEventAmount = bookEvent.amount;
		recordBookEvent({ bookEvent });
	},
	finalWin: async (bookEvent: BookEventOfType<'finalWin'>) => {
		const hasWin = bookEvent.amount > 0 || stateBet.winBookEventAmount > 0;
		if (hasWin && !skipPlaybackGate()) {
			stateGame.awaitingCollect = true;
			await waitForResolve((resolve) => {
				stateGame.continueCollect = resolve;
			});
			stateGame.continueCollect = null;
			stateGame.awaitingCollect = false;
		}
		stateGame.roundState = 'settled';
		recordBookEvent({ bookEvent });
	},
};
