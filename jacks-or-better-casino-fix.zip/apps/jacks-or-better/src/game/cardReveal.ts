import { stateBet } from 'state-shared';
import { waitForTimeout } from 'utils-shared/wait';

import { stateGame } from './stateGame.svelte';

/** Same per-card cadence as the draw handler in bookEventHandlerMap. */
export const CARD_REVEAL_MS = 280;

export const cardRevealDelay = () =>
	stateBet.isTurbo ? Promise.resolve() : waitForTimeout(CARD_REVEAL_MS);

/** Flip/reveal one card slot using the shared draw animation (lift + blue face → face up). */
export const revealCardSlot = async (index: number, code: string, held = false) => {
	const prev = stateGame.cards[index] ?? { code: '', held: false, drawing: false };
	stateGame.cards[index] = { ...prev, drawing: true };
	await cardRevealDelay();
	stateGame.cards[index] = { code, held, drawing: false };
};

/** Reveal every card in a deal (Bet / bonus-buy initial hand). */
export const revealDealHand = async (cards: { card: string }[]) => {
	stateGame.cards = cards.map(() => ({ code: '', held: false, drawing: false }));
	for (let i = 0; i < cards.length; i++) {
		await revealCardSlot(i, cards[i].card, false);
	}
};

/** Reveal only non-held slots on draw, preserving held cards. */
export const revealDrawnCards = async (
	drawn: { card: string }[],
	finalHand: { card: string }[],
	holdMask: number,
) => {
	const isHeld = (mask: number, index: number) => Boolean(mask & (1 << index));
	let drawCursor = 0;
	for (let i = 0; i < stateGame.cards.length; i++) {
		if (isHeld(holdMask, i)) continue;
		const next = drawn[drawCursor++];
		await revealCardSlot(i, next?.card ?? finalHand[i]?.card ?? stateGame.cards[i].code, false);
	}
	stateGame.cards = finalHand.map((c, index) => ({
		code: c.card,
		held: isHeld(holdMask, index),
		drawing: false,
	}));
};

/** Instant final board — same semantics as applyEventInstant in utils.ts. */
export const setDealHandInstant = (cards: { card: string }[]) => {
	stateGame.cards = cards.map((c) => ({ code: c.card, held: false, drawing: false }));
};

export const setDrawHandInstant = (finalHand: { card: string }[], holdMask: number) => {
	const isHeld = (mask: number, index: number) => Boolean(mask & (1 << index));
	stateGame.cards = finalHand.map((c, index) => ({
		code: c.card,
		held: isHeld(holdMask, index),
		drawing: false,
	}));
};
