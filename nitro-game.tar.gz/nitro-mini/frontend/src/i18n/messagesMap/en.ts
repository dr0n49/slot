export default {
	HOME: 'HOME',
};
